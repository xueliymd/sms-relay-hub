import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_compose_uses_postgres_and_required_runtime_secrets() -> None:
    compose = (ROOT / "deploy" / "compose.yml").read_text(encoding="utf-8")

    assert "  postgres:" in compose
    assert "DATABASE_URL:" in compose
    assert "POSTGRES_PASSWORD:" in compose
    assert "condition: service_healthy" in compose
    assert "STATE_FILE:" not in compose
    assert '"${HTTP_PORT:-80}:80"' in compose
    assert '"${HTTPS_PORT:-443}:443"' in compose
    assert '"${HTTPS_PORT:-443}:443/udp"' in compose
    assert "APP_PORT: ${APP_PORT:-8000}" in compose
    assert '"${APP_PORT:-8000}"' in compose
    assert "os.environ.get('APP_PORT', '8000')" in compose


def test_caddy_uses_explicit_http_or_domain_site_without_a_fake_hostname() -> None:
    env_example = (ROOT / "deploy" / ".env.example").read_text(encoding="utf-8")
    bootstrap = (ROOT / "deploy" / "bootstrap.ps1").read_text(encoding="utf-8")
    caddy = (ROOT / "deploy" / "Caddyfile").read_text(encoding="utf-8")

    assert "RELAY_SITE=:80" in env_example
    assert "RELAY_SITE = ':80'" in bootstrap
    assert "{$RELAY_SITE}" in caddy
    assert "reverse_proxy app:{$APP_PORT}" in caddy
    assert "relay.example.com" not in caddy


def test_deployment_documents_keep_caddy_internal_and_host_ports_separate() -> None:
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    deploy_readme = (ROOT / "deploy" / "README.md").read_text(encoding="utf-8")

    assert "不要改成 `:18080` 之类的外部端口" in readme
    assert "宿主机 `18080 -> Caddy 容器 80`" in deploy_readme
    assert "`RELAY_SITE=:80`" in deploy_readme
    assert "改为 `RELAY_SITE=:18080`" not in deploy_readme


def test_deployment_bootstrap_generates_missing_secrets_without_overwriting_existing_values() -> None:
    bootstrap = (ROOT / "deploy" / "bootstrap.ps1").read_text(encoding="utf-8")

    assert "RandomNumberGenerator" in bootstrap
    assert "ADMIN_TOKEN" in bootstrap
    assert "ADMIN_USERNAME" in bootstrap
    assert "ADMIN_PASSWORD" in bootstrap
    assert "DATA_ENCRYPTION_KEY" in bootstrap
    assert "POSTGRES_PASSWORD" in bootstrap
    assert "DATABASE_URL" in bootstrap
    assert "Test-Path -LiteralPath $Path" in bootstrap
    assert "Set-Content -LiteralPath $envFile" in bootstrap
    assert "Do not overwrite" in bootstrap
    assert "APP_PORT = '8000'" in bootstrap
    assert "Generated administrator credentials" in bootstrap
    assert "Recovery token" in bootstrap


def test_compose_passes_admin_login_credentials_to_the_application() -> None:
    compose = (ROOT / "deploy" / "compose.yml").read_text(encoding="utf-8")

    assert "ADMIN_USERNAME: ${ADMIN_USERNAME:?set ADMIN_USERNAME in .env}" in compose
    assert "ADMIN_PASSWORD: ${ADMIN_PASSWORD:?set ADMIN_PASSWORD in .env}" in compose


def test_unix_bootstrap_generates_and_reports_admin_credentials() -> None:
    bootstrap = (ROOT / "deploy" / "bootstrap.sh").read_text(encoding="utf-8")

    assert "set_if_empty ADMIN_USERNAME admin" in bootstrap
    assert "set_if_empty ADMIN_PASSWORD" in bootstrap
    assert "Generated administrator credentials" in bootstrap
    assert "Recovery token" in bootstrap


def test_container_runs_migrations_before_the_api() -> None:
    dockerfile = (ROOT / "deploy" / "Dockerfile").read_text(encoding="utf-8")
    entrypoint = (ROOT / "deploy" / "entrypoint.sh").read_text(encoding="utf-8")
    migration_env = (ROOT / "backend" / "migrations" / "env.py").read_text(encoding="utf-8")

    assert "deploy/entrypoint.sh" in dockerfile
    assert "alembic upgrade head" in entrypoint
    assert "exec uvicorn" in entrypoint
    assert '${APP_PORT:-8000}' in entrypoint
    assert "--workers 1" in entrypoint
    assert 'os.environ.get("DATABASE_URL", "")' in migration_env


def test_deployment_keeps_single_worker_for_the_in_process_otp_broker() -> None:
    entrypoint = (ROOT / "deploy" / "entrypoint.sh").read_text(encoding="utf-8")
    caddy = (ROOT / "deploy" / "Caddyfile").read_text(encoding="utf-8")
    plan = (ROOT / "docs" / "superpowers" / "plans" / "2026-08-23-air724-websocket-otp.md").read_text(encoding="utf-8")

    assert "--workers 1" in entrypoint
    assert "reverse_proxy app:{$APP_PORT}" in caddy
    assert "single-process" in plan
    assert "shared Redis/PostgreSQL notification broker" in plan


def test_air724_download_package_is_in_the_server_assets() -> None:
    downloads = ROOT / "web" / "public" / "assets" / "downloads"

    assert (downloads / "air724-otp-websocket.lua").is_file()
    assert (downloads / "air724-otp-websocket" / "main.lua").is_file()
    assert (downloads / "air724-otp-websocket" / "config.example.lua").is_file()
    assert (downloads / "air724-otp-websocket" / "README.md").is_file()


def test_generic_script_api_reference_client_is_in_the_server_package_source() -> None:
    script_client = ROOT / "clients" / "script_api"

    assert (script_client / "otp_client.py").is_file()
    assert (script_client / "README.md").is_file()
    assert (ROOT / "backend" / "tests" / "test_script_api_network.py").is_file()


def test_alembic_has_no_implicit_local_database_fallback() -> None:
    alembic_ini = (ROOT / "backend" / "alembic.ini").read_text(encoding="utf-8")
    migration_env = (ROOT / "backend" / "migrations" / "env.py").read_text(encoding="utf-8")

    assert "relay-dev.db" not in alembic_ini
    assert "__DATABASE_URL_REQUIRED__" in alembic_ini
    assert "DATABASE_URL must be set" in migration_env


def test_local_preview_runs_migrations_before_starting_the_api() -> None:
    preview_script = (ROOT / "debug" / "start-preview.ps1").read_text(encoding="utf-8")

    migration = "Invoke-Alembic -Command 'upgrade'"
    api_start = "'-m', 'uvicorn', 'app.main:app'"
    assert migration in preview_script
    assert preview_script.index(migration) < preview_script.index(api_start)


def test_local_preview_archives_legacy_database_before_migration() -> None:
    preview_script = (ROOT / "debug" / "start-preview.ps1").read_text(encoding="utf-8")

    archive = "Move-Item -LiteralPath $databaseFile"
    migration = "Invoke-Alembic -Command 'upgrade'"
    assert archive in preview_script
    assert ".bak-" in preview_script
    assert preview_script.index(archive) < preview_script.index(migration)


def test_local_preview_preserves_migrated_database_and_listens_on_lan() -> None:
    preview_script = (ROOT / "debug" / "start-preview.ps1").read_text(encoding="utf-8")

    assert "hasMigrationTable" in preview_script
    assert "--host', '0.0.0.0'" in preview_script
    assert "Preview Android" not in preview_script


def test_local_preview_exposes_and_checks_the_selected_database_identity() -> None:
    preview_script = (ROOT / "debug" / "start-preview.ps1").read_text(encoding="utf-8")

    assert "$databaseFingerprint" in preview_script
    assert "/api/v1/admin/runtime" in preview_script
    assert "$runtime.database_fingerprint -ne $databaseFingerprint" in preview_script
    assert "database_backend=$($runtime.database_backend)" in preview_script
    assert "database_fingerprint=$($runtime.database_fingerprint)" in preview_script


def test_preview_restores_parent_environment_and_cleans_failed_children() -> None:
    preview_script = (ROOT / "debug" / "start-preview.ps1").read_text(encoding="utf-8")

    assert "$previousRuntimeEnvironment" in preview_script
    assert "finally {" in preview_script
    assert "[Environment]::SetEnvironmentVariable" in preview_script
    assert "$previewReady" in preview_script
    assert "Stop-PreviewProcessTree -Process $process" in preview_script


def test_repository_ignores_runtime_databases_but_tracks_the_preview_launcher() -> None:
    ignore = (ROOT / ".gitignore").read_text(encoding="utf-8")

    assert "*.db" in ignore
    assert "*.db.bak-*" in ignore
    assert "*-wal" in ignore
    assert "*-shm" in ignore
    assert "!debug/start-preview.ps1" in ignore


def test_local_preview_refuses_occupied_ports_and_reports_listener_pids() -> None:
    preview_script = (ROOT / "debug" / "start-preview.ps1").read_text(encoding="utf-8")

    port_check = "Get-NetTCPConnection -LocalPort $port -State Listen"
    backend_start = "$backend = Start-Process"
    assert port_check in preview_script
    assert preview_script.index(port_check) < preview_script.index(backend_start)
    assert "$backendListener.OwningProcess" in preview_script
    assert "$webListener.OwningProcess" in preview_script
    assert "$backendListener = Wait-PreviewListener -Port $BackendPort -Process $backend" in preview_script
    assert "$webListener = Wait-PreviewListener -Port $WebPort -Process $web" in preview_script
    assert 'backend_pid=$($backendListener.OwningProcess)' in preview_script
    assert 'web_pid=$($webListener.OwningProcess)' in preview_script


def test_local_preview_ports_are_configurable() -> None:
    preview_script = (ROOT / "debug" / "start-preview.ps1").read_text(encoding="utf-8")

    assert "[int]$BackendPort = 8000" in preview_script
    assert "[int]$WebPort = 5173" in preview_script
    assert "'--port', $BackendPort" in preview_script
    assert "'--port', $WebPort" in preview_script
    assert '"http://127.0.0.1:$BackendPort/api/v1/health"' in preview_script
    assert '"http://127.0.0.1:$WebPort/"' in preview_script


def test_local_preview_avoids_fragile_python_inline_commands() -> None:
    preview_script = (ROOT / "debug" / "start-preview.ps1").read_text(encoding="utf-8")

    assert "function Invoke-Alembic" in preview_script
    assert "Invoke-Alembic -Command 'current'" in preview_script
    assert "RedirectStandardError" in preview_script
    assert "& $backendPython -m alembic" not in preview_script
    assert "sqlite3,sys" not in preview_script
    assert "hashlib,sys" not in preview_script


def test_database_artifacts_are_ignored_and_storage_boundaries_are_documented() -> None:
    gitignore = (ROOT / ".gitignore").read_text(encoding="utf-8")
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    debug_readme = (ROOT / "debug" / "README.md").read_text(encoding="utf-8")
    deploy_readme = (ROOT / "deploy" / "README.md").read_text(encoding="utf-8")

    for pattern in ("*.db", "*.db-wal", "*.db-shm", "*.sqlite", "*.sqlite3"):
        assert pattern in gitignore
    assert "`debug/preview.db`" in debug_readme
    assert "`database_fingerprint`" in debug_readme
    assert "`postgres_data`" in deploy_readme
    assert "`/data/adb/sms-relay`" in readme
    assert "`sms-relay-queue.db`" in readme


def test_server_package_excludes_local_runtime_and_secret_files() -> None:
    package_script = (ROOT / "deploy" / "package.ps1").read_text(encoding="utf-8")

    assert "web/public" in package_script
    assert "node_modules" in package_script
    assert "backend/.venv" in package_script
    assert "backend/.mypy_cache" in package_script
    assert "backend/.pytest_cache" in package_script
    assert "backend/.ruff_cache" in package_script
    assert "__pycache__" in package_script
    assert "sqlite3" in package_script
    assert ".pyc" in package_script
    assert "deploy/.env" in package_script
    assert "deploy/dist" in package_script
    assert ".dockerignore" in package_script
    assert "web/public/assets/downloads/air724-otp-websocket.lua" in package_script
    assert "web/public/assets/downloads/air724-otp-websocket/main.lua" in package_script
    assert "web/public/assets/downloads/air724-otp-websocket/config.example.lua" in package_script
    assert "web/public/assets/downloads/air724-otp-websocket/README.md" in package_script
    assert "clients/script_api/otp_client.py" in package_script
    assert "clients/script_api/README.md" in package_script
    assert "web/public/assets/releases/release-catalog.json" in package_script
    assert "release.download_url" in package_script
    assert "manager-android" in package_script
    assert "*.p12" in package_script
    assert "*signing.properties" in package_script


def test_manager_release_scripts_require_external_signing_and_publish_history() -> None:
    build_script = (ROOT / "manager-android" / "build-release.ps1").read_text(encoding="utf-8")
    publish_script = (ROOT / "manager-android" / "publish-update.ps1").read_text(encoding="utf-8")

    for variable in (
        "RELAY_MANAGER_SIGNING_STORE_FILE",
        "RELAY_MANAGER_SIGNING_STORE_PASSWORD",
        "RELAY_MANAGER_SIGNING_KEY_ALIAS",
        "RELAY_MANAGER_SIGNING_KEY_PASSWORD",
    ):
        assert variable in build_script
    assert "io.smsrelay.manager" in publish_script
    assert "platform = 'manager'" in publish_script
    assert "Relay-Hub-Manager-$versionName.apk" in publish_script
    assert "Signer SHA-256" in publish_script


def test_published_manager_release_matches_catalog_and_apk() -> None:
    catalog_path = ROOT / "web" / "public" / "assets" / "releases" / "release-catalog.json"
    catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
    manager_releases = [release for release in catalog["releases"] if release["platform"] == "manager"]

    assert manager_releases
    release = max(manager_releases, key=lambda item: item["version_code"])
    assert release["version_code"] == 1
    assert release["version_name"] == "1.0.0"
    assert release["download_url"].startswith("/assets/releases/manager/")
    assert len(release["signer_sha256"]) == 64
    apk = ROOT / "web" / "public" / release["download_url"].removeprefix("/")
    assert apk.is_file()
    assert apk.stat().st_size == release["size_bytes"]
    assert hashlib.sha256(apk.read_bytes()).hexdigest() == release["sha256"]


def test_root_module_publish_script_and_release_history_are_consistent() -> None:
    publish_script = (ROOT / "clients" / "root-module" / "publish-update.ps1").read_text(encoding="utf-8")
    assert "platform = 'root'" in publish_script
    assert "signer_sha256 = $null" in publish_script
    assert "module.prop" in publish_script

    catalog_path = ROOT / "web" / "public" / "assets" / "releases" / "release-catalog.json"
    catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
    root_releases = [release for release in catalog["releases"] if release["platform"] == "root"]
    assert root_releases
    release = max(root_releases, key=lambda item: item["version_code"])
    assert release["version_code"] == 19
    assert release["version_name"] == "0.3.7"
    assert release["signer_sha256"] is None
    archive = ROOT / "web" / "public" / release["download_url"].removeprefix("/")
    assert archive.is_file()
    assert archive.stat().st_size == release["size_bytes"]
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == release["sha256"]


def test_container_update_package_preserves_release_store_and_matches_catalog() -> None:
    package_update = (ROOT / "deploy" / "package-update.ps1").read_text(encoding="utf-8")
    package_script = (ROOT / "deploy" / "package.ps1").read_text(encoding="utf-8")
    publish_update = (ROOT / "deploy" / "publish-update.ps1").read_text(encoding="utf-8")
    apply_update = (ROOT / "deploy" / "apply-update.sh").read_text(encoding="utf-8")

    assert "-ExcludeReleaseStore" in package_update
    assert "web/public/assets/releases" in package_script
    assert "platform = 'deploy'" in publish_update
    assert "signer_sha256 = $null" in publish_update
    assert "relay-backup-" in apply_update
    assert "web/public/assets/releases" in apply_update
    assert "deploy/.env" in apply_update
    assert "docker compose" in apply_update

    catalog_path = ROOT / "web" / "public" / "assets" / "releases" / "release-catalog.json"
    catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
    deploy_releases = [release for release in catalog["releases"] if release["platform"] == "deploy"]
    assert deploy_releases
    release = max(deploy_releases, key=lambda item: item["version_code"])
    assert release["version_code"] == 20260901
    assert release["version_name"] == "2026.09.01"
    assert release["signer_sha256"] is None
    archive = ROOT / "web" / "public" / release["download_url"].removeprefix("/")
    assert archive.is_file()
    assert archive.stat().st_size == release["size_bytes"]
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == release["sha256"]


def test_every_release_catalog_artifact_matches_declared_size_and_hash() -> None:
    catalog_path = ROOT / "web" / "public" / "assets" / "releases" / "release-catalog.json"
    catalog = json.loads(catalog_path.read_text(encoding="utf-8"))

    assert catalog["releases"]
    for release in catalog["releases"]:
        artifact = ROOT / "web" / "public" / release["download_url"].removeprefix("/")
        assert artifact.is_file(), release["download_url"]
        assert artifact.stat().st_size == release["size_bytes"], release["download_url"]
        assert hashlib.sha256(artifact.read_bytes()).hexdigest() == release["sha256"], release["download_url"]
