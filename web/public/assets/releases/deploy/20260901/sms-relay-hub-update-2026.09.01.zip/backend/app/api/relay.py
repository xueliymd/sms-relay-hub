import asyncio
import hashlib
import json
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Body, Header, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse, PlainTextResponse

from app.core.config import settings
from app.core.errors import RelayError
from app.services.admin_message_websocket import (
    AdminMessageSubscription,
    admin_message_broker,
)
from app.services.otp_websocket import OtpSubscription, otp_broker
from app.services.store import (
    SUPPORTED_DEVICE_CONTRACTS,
    DeviceSimProfile,
    IdempotencyConflict,
    InvalidDeviceCredential,
    normalize_phone_number,
    store,
)

router = APIRouter(prefix="/api/v1", tags=["relay"])
MAX_INGEST_BODY_BYTES = 32 * 1024
MAX_WS_FRAME_BYTES = 8 * 1024
WS_AUTH_TIMEOUT_SECONDS = 10.0
WS_SUBSCRIPTION_TIMEOUT_SECONDS = 10.0
WS_IDLE_TIMEOUT_SECONDS = 180.0


class _FailedScriptAuthLimiter:
    """Small process-local lockout for repeated invalid script credentials.

    This intentionally only covers failed script-token authentication. It is
    not a request rate limiter and does not affect valid shortcut/module traffic.
    """

    def __init__(self, *, max_failures: int = 5, lock_seconds: int = 600) -> None:
        self.max_failures = max_failures
        self.lock_seconds = lock_seconds
        self._entries: dict[str, tuple[int, float]] = {}
        self._lock = threading.Lock()

    def clear(self) -> None:
        with self._lock:
            self._entries.clear()

    def is_locked(self, client_ip: str) -> bool:
        now = time.monotonic()
        with self._lock:
            entry = self._entries.get(client_ip)
            if entry is None:
                return False
            failures, locked_until = entry
            if locked_until > now:
                return True
            if locked_until:
                self._entries.pop(client_ip, None)
            return False

    def record_failure(self, client_ip: str) -> None:
        now = time.monotonic()
        with self._lock:
            failures, locked_until = self._entries.get(client_ip, (0, 0.0))
            if locked_until > now:
                return
            failures += 1
            self._entries[client_ip] = (
                failures,
                now + self.lock_seconds if failures >= self.max_failures else 0.0,
            )

    def reset(self, client_ip: str) -> None:
        with self._lock:
            self._entries.pop(client_ip, None)


script_auth_limiter = _FailedScriptAuthLimiter()


class _WebSocketFrameTooLarge(ValueError):
    pass


def _client_ip(connection: Request | WebSocket) -> str:
    client = connection.client
    host = getattr(client, "host", None)
    return host if isinstance(host, str) and host else "unknown"


def _script_token_from_authorization(authorization: str | None) -> str | None:
    if not authorization or not authorization.lower().startswith("bearer "):
        return None
    token = authorization.split(" ", 1)[1].strip()
    return token or None


def _authenticate_script_token(token: str | None, client_ip: str) -> None:
    if script_auth_limiter.is_locked(client_ip):
        raise RelayError(429, "script_auth_locked", "Too many invalid script credentials from this IP")
    if token is None or not store.authenticate_api_client(token):
        script_auth_limiter.record_failure(client_ip)
        raise RelayError(401, "invalid_api_client", "Script API token is invalid")
    script_auth_limiter.reset(client_ip)


async def _receive_json_frame(websocket: WebSocket, timeout_seconds: float) -> dict[str, Any]:
    raw = await asyncio.wait_for(websocket.receive_text(), timeout=timeout_seconds)
    if len(raw.encode("utf-8")) > MAX_WS_FRAME_BYTES:
        raise _WebSocketFrameTooLarge()
    try:
        frame = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError("frame must be valid JSON") from exc
    if not isinstance(frame, dict):
        raise ValueError("frame must be a JSON object")
    return frame

def require_admin(value: str | None) -> None:
    if not store.validate_admin_credential(value):
        raise RelayError(401, "admin_auth_required", "Admin token is invalid")


SIM_PROFILE_SOURCES = {"auto", "manual", "vendor"}
POSTGRES_INTEGER_MIN = -(2**31)
POSTGRES_INTEGER_MAX = 2**31 - 1


def _script_token_from_frame(frame: Any) -> str:
    if not isinstance(frame, dict) or frame.get("type") != "auth":
        raise ValueError("first frame must be an auth frame")
    token = frame.get("token")
    if not isinstance(token, str) or not token.strip():
        raise ValueError("token is required")
    return token.strip()


def _subscription_from_frame(frame: Any) -> OtpSubscription:
    if not isinstance(frame, dict) or frame.get("type") != "subscribe":
        raise ValueError("subscribe frame is required")
    phone_number = frame.get("phone_number")
    if not isinstance(phone_number, str) or not phone_number.strip():
        raise ValueError("phone_number is required")
    device_id = frame.get("device_id")
    if device_id is not None:
        device_id = str(UUID(str(device_id)))
    sender = frame.get("sender")
    keyword = frame.get("keyword")
    if sender is not None and not isinstance(sender, str):
        raise ValueError("sender must be a string")
    if keyword is not None and not isinstance(keyword, str):
        raise ValueError("keyword must be a string")
    return OtpSubscription(
        phone_number=phone_number,
        device_id=device_id,
        sender=sender,
        keyword=keyword,
    )


def _admin_message_subscription_from_frame(frame: Any) -> AdminMessageSubscription:
    if not isinstance(frame, dict) or frame.get("type") != "subscribe":
        raise ValueError("subscribe frame is required")
    raw_device_id = frame.get("device_id")
    if not isinstance(raw_device_id, str) or not raw_device_id.strip():
        raise ValueError("device_id is required")
    device_id = UUID(raw_device_id.strip())
    sim_slot = frame.get("sim_slot")
    if sim_slot is not None and (
        isinstance(sim_slot, bool) or not isinstance(sim_slot, int) or sim_slot < 0
    ):
        raise ValueError("sim_slot must be a non-negative integer")
    return AdminMessageSubscription(device_id=str(device_id), sim_slot=sim_slot)


@router.websocket("/ws/otp")
async def otp_websocket(websocket: WebSocket) -> None:
    await websocket.accept()
    authenticated = False
    client_ip = _client_ip(websocket)
    try:
        try:
            auth_frame = await _receive_json_frame(websocket, WS_AUTH_TIMEOUT_SECONDS)
            token = _script_token_from_frame(auth_frame)
        except TimeoutError:
            await websocket.send_json({"type": "error", "code": "auth_timeout", "message": "Authentication frame timed out"})
            await websocket.close(code=1008)
            return
        except _WebSocketFrameTooLarge:
            await websocket.send_json({"type": "error", "code": "frame_too_large", "message": "WebSocket control frame is too large"})
            await websocket.close(code=1009)
            return
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            await websocket.send_json({"type": "error", "code": "invalid_auth", "message": str(exc)})
            await websocket.close(code=1008)
            return
        try:
            _authenticate_script_token(token, client_ip)
        except RelayError as exc:
            await websocket.send_json(
                {
                    "type": "error",
                    "code": exc.code,
                    "message": exc.message,
                }
            )
            await websocket.close(code=1008)
            return
        authenticated = True
        await websocket.send_json({"type": "auth_ok"})

        try:
            subscription_frame = await _receive_json_frame(
                websocket, WS_SUBSCRIPTION_TIMEOUT_SECONDS
            )
            subscription = _subscription_from_frame(subscription_frame)
        except TimeoutError:
            await websocket.send_json({"type": "error", "code": "subscription_timeout", "message": "Subscription frame timed out"})
            await websocket.close(code=1008)
            return
        except _WebSocketFrameTooLarge:
            await websocket.send_json({"type": "error", "code": "frame_too_large", "message": "WebSocket control frame is too large"})
            await websocket.close(code=1009)
            return
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            await websocket.send_json({"type": "error", "code": "invalid_subscription", "message": str(exc)})
            await websocket.close(code=1008)
            return
        await otp_broker.add(websocket, subscription)
        await websocket.send_json(
            {
                "type": "subscribed",
                "phone_number": subscription.phone_number,
                "device_id": subscription.device_id,
                "server_time": datetime.now(timezone.utc).isoformat(),
            }
        )
        while True:
            try:
                frame = await _receive_json_frame(websocket, WS_IDLE_TIMEOUT_SECONDS)
            except TimeoutError:
                await websocket.send_json({"type": "error", "code": "idle_timeout", "message": "WebSocket closed after 3 minutes without client activity"})
                await websocket.close(code=1000)
                return
            except _WebSocketFrameTooLarge:
                await websocket.send_json({"type": "error", "code": "frame_too_large", "message": "WebSocket control frame is too large"})
                await websocket.close(code=1009)
                return
            if frame.get("type") == "ping":
                await websocket.send_json({"type": "pong"})
            elif frame.get("type") == "subscribe":
                await websocket.send_json(
                    {
                        "type": "error",
                        "code": "subscription_already_set",
                        "message": "Only one subscription is allowed per connection",
                    }
                )
                await websocket.close(code=1008)
                return
    except WebSocketDisconnect:
        return
    finally:
        if authenticated:
            await otp_broker.remove(websocket)


@router.websocket("/ws/admin/messages")
async def admin_message_websocket(websocket: WebSocket) -> None:
    await websocket.accept()
    subscribed = False
    token: str | None = None
    try:
        try:
            auth_frame = await _receive_json_frame(websocket, WS_AUTH_TIMEOUT_SECONDS)
            token = _script_token_from_frame(auth_frame)
        except TimeoutError:
            await websocket.send_json(
                {
                    "type": "error",
                    "code": "auth_timeout",
                    "message": "Authentication frame timed out",
                }
            )
            await websocket.close(code=1008)
            return
        except _WebSocketFrameTooLarge:
            await websocket.send_json(
                {
                    "type": "error",
                    "code": "frame_too_large",
                    "message": "WebSocket control frame is too large",
                }
            )
            await websocket.close(code=1009)
            return
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            await websocket.send_json(
                {"type": "error", "code": "invalid_auth", "message": str(exc)}
            )
            await websocket.close(code=1008)
            return
        if not store.validate_admin_credential(token):
            await websocket.send_json(
                {
                    "type": "error",
                    "code": "admin_auth_required",
                    "message": "Admin token is invalid",
                }
            )
            await websocket.close(code=1008)
            return
        await websocket.send_json({"type": "auth_ok"})

        try:
            subscription_frame = await _receive_json_frame(
                websocket, WS_SUBSCRIPTION_TIMEOUT_SECONDS
            )
            subscription = _admin_message_subscription_from_frame(subscription_frame)
        except TimeoutError:
            await websocket.send_json(
                {
                    "type": "error",
                    "code": "subscription_timeout",
                    "message": "Subscription frame timed out",
                }
            )
            await websocket.close(code=1008)
            return
        except _WebSocketFrameTooLarge:
            await websocket.send_json(
                {
                    "type": "error",
                    "code": "frame_too_large",
                    "message": "WebSocket control frame is too large",
                }
            )
            await websocket.close(code=1009)
            return
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            await websocket.send_json(
                {
                    "type": "error",
                    "code": "invalid_subscription",
                    "message": str(exc),
                }
            )
            await websocket.close(code=1008)
            return

        device = store.get_device(UUID(subscription.device_id))
        if device is None or not device.active:
            await websocket.send_json(
                {
                    "type": "error",
                    "code": "device_not_active",
                    "message": "Device is missing or inactive",
                }
            )
            await websocket.close(code=1008)
            return

        await admin_message_broker.add(websocket, subscription)
        subscribed = True
        await websocket.send_json(
            {
                "type": "subscribed",
                "device_id": subscription.device_id,
                "sim_slot": subscription.sim_slot,
                "server_time": datetime.now(timezone.utc).isoformat(),
            }
        )

        while True:
            try:
                frame = await _receive_json_frame(websocket, WS_IDLE_TIMEOUT_SECONDS)
            except TimeoutError:
                await websocket.send_json(
                    {
                        "type": "error",
                        "code": "idle_timeout",
                        "message": "WebSocket closed after 3 minutes without client activity",
                    }
                )
                await websocket.close(code=1000)
                return
            except _WebSocketFrameTooLarge:
                await websocket.send_json(
                    {
                        "type": "error",
                        "code": "frame_too_large",
                        "message": "WebSocket control frame is too large",
                    }
                )
                await websocket.close(code=1009)
                return

            if not store.validate_admin_credential(token):
                await websocket.send_json(
                    {
                        "type": "error",
                        "code": "admin_auth_required",
                        "message": "Admin session is no longer valid",
                    }
                )
                await websocket.close(code=1008)
                return
            if frame.get("type") == "ping":
                await websocket.send_json({"type": "pong"})
            elif frame.get("type") == "subscribe":
                await websocket.send_json(
                    {
                        "type": "error",
                        "code": "subscription_already_set",
                        "message": "Only one subscription is allowed per connection",
                    }
                )
                await websocket.close(code=1008)
                return
    except WebSocketDisconnect:
        return
    finally:
        if subscribed:
            await admin_message_broker.remove(websocket)


def _validate_sim_profile_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("request body must be a JSON object")
    allowed = {"subscription_id", "phone_number", "carrier_name", "source"}
    unknown = set(payload) - allowed
    if unknown:
        raise ValueError("unsupported SIM profile field")
    if "subscription_id" in payload and payload["subscription_id"] is not None:
        if isinstance(payload["subscription_id"], bool) or not isinstance(payload["subscription_id"], int):
            raise ValueError("subscription_id must be an integer or null")
        if not POSTGRES_INTEGER_MIN <= payload["subscription_id"] <= POSTGRES_INTEGER_MAX:
            raise ValueError("subscription_id is outside the supported integer range")
    validated = dict(payload)
    for field_name in ("phone_number", "carrier_name"):
        if field_name in payload and payload[field_name] is not None:
            if not isinstance(payload[field_name], str):
                raise ValueError(f"{field_name} must be a string or null")
            if field_name == "phone_number":
                validated[field_name] = normalize_phone_number(payload[field_name])
            elif len(payload[field_name]) > 160:
                raise ValueError(f"{field_name} is too long")
    if "source" in payload and (
        not isinstance(payload["source"], str) or payload["source"] not in SIM_PROFILE_SOURCES
    ):
        raise ValueError("source must be one of auto, manual, vendor")
    return validated


def _validate_sim_slot(slot: int) -> None:
    if slot < 0 or slot > POSTGRES_INTEGER_MAX:
        raise RelayError(422, "invalid_sim_profile", "slot_index is outside the supported range")


def _mask_phone_number(phone_number: str | None) -> str | None:
    if phone_number is None:
        return None
    digit_count = sum(character.isdigit() for character in phone_number)
    if digit_count <= 4:
        return "*" * len(phone_number)
    return "*" * (len(phone_number) - 4) + phone_number[-4:]


def _serialize_message(message: Any) -> dict[str, Any]:
    subscription_id = message.metadata.get("subscription_id")
    if not isinstance(subscription_id, int) or isinstance(subscription_id, bool):
        subscription_id = None
    return {
        "id": str(message.id),
        "device_id": str(message.device_id),
        "client_message_id": message.client_message_id,
        "received_at": message.received_at.isoformat(),
        "created_at": message.created_at.isoformat(),
        "sender": message.sender,
        "body": None if message.redacted else message.body,
        "source": message.source,
        "sim_slot": message.sim_slot,
        "subscription_id": subscription_id,
        "receiving_phone_masked": _mask_phone_number(message.receiving_phone),
        "receiving_identity_status": message.receiving_identity_status,
        "otp_status": message.otp_status,
        "read_at": message.read_at.isoformat() if message.read_at else None,
        "metadata": message.metadata,
        "redacted": message.redacted,
    }


async def _publish_admin_message(message: Any) -> None:
    event = _serialize_message(message)
    otp_event = store.get_otp_delivery(message.id)
    event["type"] = "message"
    event["otp_code"] = otp_event["code"] if otp_event else None
    event["cursor"] = {"created_at": event["created_at"], "id": event["id"]}
    await admin_message_broker.publish(event)


def _serialize_sim_profile(profile: DeviceSimProfile) -> dict[str, Any]:
    return {
        "device_id": str(profile.device_id),
        "slot_index": profile.slot_index,
        "subscription_id": profile.subscription_id,
        "phone_number_masked": _mask_phone_number(profile.phone_number),
        "carrier_name": profile.carrier_name,
        "source": profile.source,
        "updated_at": profile.updated_at.isoformat(),
    }


def _serialize_device(device: Any) -> dict[str, Any]:
    online_cutoff = datetime.now(timezone.utc) - timedelta(
        seconds=settings.device_online_window_seconds
    )
    return {
        "id": str(device.id),
        "name": device.name,
        "client_type": device.client_type,
        "auth_kind": device.auth_kind,
        "active": device.active,
        "online": bool(
            device.active
            and device.last_seen_at is not None
            and device.last_seen_at >= online_cutoff
        ),
        "last_seen_at": device.last_seen_at.isoformat() if device.last_seen_at else None,
        "client_instance_id": device.client_instance_id,
        "client_version": device.client_version,
        "client_mode": device.client_mode,
        "runtime_updated_at": (
            device.runtime_updated_at.isoformat() if device.runtime_updated_at else None
        ),
        "credential_reuse_warning": device.credential_reuse_warning,
        "duplicate_collection_warning": device.duplicate_collection_warning,
    }


def _admin_session_response(account_id: str, username: str, session_version: int) -> dict[str, Any]:
    token, expires_at = store.issue_admin_session(account_id, username, session_version)
    return {
        "token": token,
        "username": username,
        "expires_at": datetime.fromtimestamp(expires_at, timezone.utc).isoformat(),
    }


@router.post("/admin/login")
async def admin_login(payload: Any = Body(...)) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise RelayError(422, "invalid_admin_login", "Request body must be an object")
    username = payload.get("username")
    password = payload.get("password")
    if not isinstance(username, str) or not isinstance(password, str):
        raise RelayError(422, "invalid_admin_login", "Username and password are required")
    account = store.authenticate_admin(username.strip(), password)
    if account is None:
        raise RelayError(401, "admin_auth_required", "Username or password is invalid")
    return _admin_session_response(*account)


@router.put("/admin/account")
async def update_admin_account(
    payload: Any = Body(...),
    x_admin_token: str | None = Header(default=None),
) -> dict[str, Any]:
    require_admin(x_admin_token)
    if not isinstance(payload, dict):
        raise RelayError(422, "invalid_admin_account", "Request body must be an object")
    current_password = payload.get("current_password")
    username = payload.get("username")
    password = payload.get("password")
    if not isinstance(current_password, str):
        raise RelayError(422, "invalid_admin_account", "Current password is required")
    if username is not None and not isinstance(username, str):
        raise RelayError(422, "invalid_admin_account", "Username must be a string")
    if password is not None and not isinstance(password, str):
        raise RelayError(422, "invalid_admin_account", "Password must be a string")
    try:
        account = store.update_admin_account(
            current_password=current_password,
            username=username,
            password=password,
        )
    except PermissionError as exc:
        raise RelayError(401, "admin_auth_required", str(exc)) from exc
    except ValueError as exc:
        raise RelayError(422, "invalid_admin_account", str(exc)) from exc
    return _admin_session_response(*account)


@router.post("/admin/devices", status_code=201)
async def create_device(payload: Any = Body(...), x_admin_token: str | None = Header(default=None)) -> dict[str, Any]:
    require_admin(x_admin_token)
    try:
        if not isinstance(payload, dict):
            raise ValueError("request body must be a JSON object")
        name = payload.get("name", "Unnamed device")
        client_type = payload["client_type"]
        auth_kind = payload["auth_kind"]
        if not isinstance(name, str):
            raise ValueError("name must be a string")
        if not isinstance(client_type, str):
            raise ValueError("client_type must be a string")
        if not isinstance(auth_kind, str):
            raise ValueError("auth_kind must be a string")
        expected = SUPPORTED_DEVICE_CONTRACTS.get(client_type)
        if expected is None or expected[0] != auth_kind:
            raise ValueError("client_type and auth_kind are not a supported pair")
        device, credential = store.create_device(name, client_type, auth_kind)
    except (KeyError, ValueError) as exc:
        raise RelayError(422, "invalid_device", str(exc)) from exc
    return {"device": {"id": str(device.id), "name": device.name, "client_type": device.client_type, "auth_kind": device.auth_kind, "active": True}, "credential": {"type": device.auth_kind, "secret": credential}}


@router.get("/admin/devices")
async def list_devices(x_admin_token: str | None = Header(default=None)) -> list[dict[str, Any]]:
    require_admin(x_admin_token)
    return [_serialize_device(device) for device in store.list_devices()]


@router.get("/admin/runtime")
async def runtime_identity(
    x_admin_token: str | None = Header(default=None),
) -> dict[str, Any]:
    require_admin(x_admin_token)
    try:
        store.check_database()
        database_status = "healthy"
    except Exception:
        database_status = "unavailable"
    return {
        "database_backend": store.engine.dialect.name,
        "database_fingerprint": store.database_fingerprint(),
        "platform_version": settings.platform_version,
        "public_base_url": settings.public_base_url,
        "relay_site": settings.relay_site,
        "http_port": settings.http_port,
        "https_port": settings.https_port,
        "app_port": settings.app_port,
        "https_enabled": settings.public_base_url.startswith("https://"),
        "services": {
            "app": "healthy",
            "database": database_status,
            "caddy": "configured" if settings.relay_site else "not_configured",
        },
        "server_time": datetime.now(timezone.utc).isoformat(),
    }


@router.post("/admin/devices/{device_id}/rotate-credential")
async def rotate_device(device_id: UUID, x_admin_token: str | None = Header(default=None)) -> dict[str, Any]:
    require_admin(x_admin_token)
    try:
        device, credential = store.rotate_device(device_id)
    except KeyError as exc:
        raise RelayError(404, "device_not_found", "Device not found") from exc
    except ValueError as exc:
        raise RelayError(409, "device_not_active", "Only active devices can rotate credentials") from exc
    return {"device": {"id": str(device.id), "active": device.active}, "credential": {"type": device.auth_kind, "secret": credential}}


@router.post("/admin/devices/{device_id}/restore")
async def restore_device(device_id: UUID, x_admin_token: str | None = Header(default=None)) -> dict[str, Any]:
    require_admin(x_admin_token)
    try:
        device, credential = store.restore_device(device_id)
    except KeyError as exc:
        raise RelayError(404, "device_not_found", "Device not found") from exc
    except ValueError as exc:
        raise RelayError(409, "device_not_revoked", "Only revoked devices can be restored") from exc
    return {"device": {"id": str(device.id), "active": device.active}, "credential": {"type": device.auth_kind, "secret": credential}}


@router.delete("/admin/devices/{device_id}/purge", status_code=204)
async def purge_device(device_id: UUID, x_admin_token: str | None = Header(default=None)) -> None:
    require_admin(x_admin_token)
    try:
        store.purge_device(device_id)
    except KeyError as exc:
        raise RelayError(404, "device_not_found", "Device not found") from exc
    except ValueError as exc:
        raise RelayError(409, "device_not_revoked", "Only revoked devices can be purged") from exc


@router.get("/admin/devices/{device_id}/sim-profiles")
async def list_sim_profiles(
    device_id: UUID, x_admin_token: str | None = Header(default=None)
) -> list[dict[str, Any]]:
    require_admin(x_admin_token)
    try:
        profiles = store.list_sim_profiles(device_id)
    except KeyError as exc:
        raise RelayError(404, "device_not_found", "Device not found") from exc
    return [_serialize_sim_profile(profile) for profile in profiles]


@router.get("/admin/devices/{device_id}/sim-profiles/{slot}")
async def get_sim_profile(
    device_id: UUID, slot: int, x_admin_token: str | None = Header(default=None)
) -> dict[str, Any]:
    require_admin(x_admin_token)
    _validate_sim_slot(slot)
    try:
        profile = store.get_sim_profile(device_id, slot)
    except KeyError as exc:
        raise RelayError(404, "device_not_found", "Device not found") from exc
    if profile is None:
        raise RelayError(404, "sim_profile_not_found", "SIM profile not found")
    return _serialize_sim_profile(profile)


@router.put("/admin/devices/{device_id}/sim-profiles/{slot}")
async def upsert_sim_profile(
    device_id: UUID,
    slot: int,
    payload: Any = Body(...),
    x_admin_token: str | None = Header(default=None),
) -> dict[str, Any]:
    require_admin(x_admin_token)
    _validate_sim_slot(slot)
    try:
        updates = _validate_sim_profile_payload(payload)
        profile = store.upsert_sim_profile(device_id, slot, updates)
    except KeyError as exc:
        raise RelayError(404, "device_not_found", "Device not found") from exc
    except ValueError as exc:
        raise RelayError(422, "invalid_sim_profile", str(exc)) from exc
    return _serialize_sim_profile(profile)


@router.delete("/admin/devices/{device_id}/sim-profiles/{slot}", status_code=204)
async def delete_sim_profile(
    device_id: UUID, slot: int, x_admin_token: str | None = Header(default=None)
) -> None:
    require_admin(x_admin_token)
    _validate_sim_slot(slot)
    try:
        store.delete_sim_profile(device_id, slot)
    except KeyError as exc:
        raise RelayError(404, "device_not_found", "Device not found") from exc
    except LookupError as exc:
        raise RelayError(404, "sim_profile_not_found", "SIM profile not found") from exc


@router.delete("/admin/devices/{device_id}", status_code=204)
async def revoke_device(device_id: UUID, x_admin_token: str | None = Header(default=None)) -> None:
    require_admin(x_admin_token)
    try:
        store.revoke_device(device_id)
    except KeyError:
        raise RelayError(404, "device_not_found", "Device not found")


def validate_ingest_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("message body must be a JSON object")
    if payload.get("schema_version") != 1:
        raise ValueError("schema_version must be 1")
    client_message_id = payload.get("client_message_id")
    sender = payload.get("sender")
    body = payload.get("body")
    metadata = payload.get("metadata", {})
    if not isinstance(client_message_id, str) or not client_message_id or len(client_message_id) > 200:
        raise ValueError("client_message_id must contain 1 to 200 characters")
    if not isinstance(sender, str) or not sender or len(sender) > 200:
        raise ValueError("sender must contain 1 to 200 characters")
    if not isinstance(body, str) or not body or len(body) > 4096:
        raise ValueError("body must contain 1 to 4096 characters")
    if not isinstance(metadata, dict) or len(json.dumps(metadata, separators=(",", ":")).encode()) > 8192:
        raise ValueError("metadata must be a JSON object no larger than 8192 bytes")
    received_at = datetime.fromisoformat(str(payload.get("received_at", "")).replace("Z", "+00:00"))
    if received_at.tzinfo is None or received_at.utcoffset() is None:
        raise ValueError("received_at must include a timezone")
    payload["received_at"] = received_at
    return payload


def _shortcut_field(message: dict[str, Any], *names: str) -> Any:
    for name in names:
        if name in message:
            return message[name]
    lowered = {str(key).lower(): value for key, value in message.items()}
    for name in names:
        if name.lower() in lowered:
            return lowered[name.lower()]
    return None


def build_shortcut_payload(
    message: Any,
    *,
    received_at: datetime | None = None,
) -> dict[str, Any]:
    """Convert an iOS ExtensionInput into the existing ingest contract."""
    now = received_at or datetime.now(timezone.utc)
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("received_at must include a timezone")
    if isinstance(message, list):
        if len(message) != 1:
            raise ValueError("message must contain exactly one item")
        message = message[0]

    sender = "iPhone Messages"
    body: Any = message
    message_date = now.replace(second=0, microsecond=0).isoformat()
    phone_value: Any = None
    if isinstance(message, dict):
        sender_value = _shortcut_field(
            message,
            "Sender",
            "sender",
            "From",
            "from",
            "\u53d1\u4ef6\u4eba",
        )
        body = _shortcut_field(
            message,
            "Content",
            "content",
            "Body",
            "body",
            "Text",
            "text",
            "Message",
            "message",
            "\u5185\u5bb9",
            "\u4fe1\u606f",
        )
        date_value = _shortcut_field(
            message,
            "Date",
            "date",
            "MessageDate",
            "message_date",
            "\u65e5\u671f",
        )
        phone_value = _shortcut_field(
            message,
            "PhoneNumber",
            "phone_number",
            "RecipientPhoneNumber",
            "recipient_phone_number",
            "To",
            "to",
            "\u63a5\u6536\u53f7\u7801",
            "\u624b\u673a\u53f7\u7801",
        )
        if isinstance(sender_value, str) and sender_value.strip():
            sender = sender_value.strip()
        if isinstance(date_value, (str, int, float)) and not isinstance(date_value, bool):
            normalized_date = str(date_value).strip()
            if normalized_date:
                message_date = normalized_date
    if not isinstance(body, str) or not body.strip():
        raise ValueError("message content must be a non-empty string")
    body = body.strip()
    canonical = f"ios-shortcut-v1\n{sender}\n{message_date}\n{body}"
    client_message_id = "ios-shortcut-v1:" + hashlib.sha256(canonical.encode()).hexdigest()
    metadata: dict[str, Any] = {
        "shortcut_version": "1.0.0",
        "ingest_mode": "shortcut",
    }
    # Newer iOS versions may include the receiving line in Shortcut Input;
    # older versions expose only sender/content/date. This is optional
    # enrichment and must never block accepting the SMS.
    if isinstance(phone_value, str):
        try:
            metadata["phone_number"] = normalize_phone_number(phone_value)
        except ValueError:
            pass
    return {
        "schema_version": 1,
        "client_message_id": client_message_id,
        "received_at": now.isoformat(),
        "sender": sender,
        "body": body,
        "source": "ios_shortcut",
        "metadata": metadata,
    }


async def read_ingest_body(request: Request) -> bytes:
    content_length = request.headers.get("content-length")
    if content_length is not None:
        try:
            if int(content_length) > MAX_INGEST_BODY_BYTES:
                raise RelayError(413, "request_too_large", "Request body is too large")
        except ValueError:
            raise RelayError(400, "invalid_content_length", "Content-Length is invalid") from None

    body = bytearray()
    async for chunk in request.stream():
        body.extend(chunk)
        if len(body) > MAX_INGEST_BODY_BYTES:
            raise RelayError(413, "request_too_large", "Request body is too large")
    return bytes(body)


@router.post("/ingest/shortcut")
async def ingest_shortcut(
    request: Request,
    authorization: str | None = Header(default=None),
) -> JSONResponse:
    raw = await read_ingest_body(request)
    try:
        request_payload = json.loads(raw)
        if not isinstance(request_payload, dict) or "message" not in request_payload:
            raise ValueError("message is required")
        payload = validate_ingest_payload(build_shortcut_payload(request_payload["message"]))
        canonical_raw = json.dumps(
            {**payload, "received_at": payload["received_at"].isoformat()},
            separators=(",", ":"),
            sort_keys=True,
        ).encode()
        stable_request = json.dumps(
            {
                "client_message_id": payload["client_message_id"],
                "sender": payload["sender"],
                "body": payload["body"],
                "source": payload["source"],
                "metadata": payload["metadata"],
            },
            separators=(",", ":"),
            sort_keys=True,
        ).encode()
        message, duplicate = store.ingest(
            raw_body=canonical_raw,
            authorization=authorization,
            device_id=None,
            timestamp=None,
            nonce=None,
            signature=None,
            idempotency_key=payload["client_message_id"],
            payload=payload,
            request_hash=hashlib.sha256(stable_request).hexdigest(),
            source_address=_client_ip(request),
        )
    except InvalidDeviceCredential as exc:
        raise RelayError(
            401,
            "invalid_device_token",
            "Device credential is invalid, replayed, or revoked",
        ) from exc
    except IdempotencyConflict as exc:
        raise RelayError(
            409,
            "idempotency_conflict",
            "Idempotency key was already used with a different request body",
        ) from exc
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise RelayError(422, "invalid_message", str(exc)) from exc
    if not duplicate:
        otp_event = store.get_otp_delivery(message.id)
        if otp_event:
            await otp_broker.publish(otp_event)
        await _publish_admin_message(message)
    return JSONResponse(
        status_code=200 if duplicate else 201,
        content={"accepted": True, "duplicate": duplicate, "message_id": str(message.id)},
    )


@router.post("/ingest/messages")
async def ingest(request: Request, authorization: str | None = Header(default=None), x_device_id: str | None = Header(default=None), x_timestamp: str | None = Header(default=None), x_nonce: str | None = Header(default=None), x_signature: str | None = Header(default=None), x_idempotency_key: str | None = Header(default=None)) -> JSONResponse:
    raw = await read_ingest_body(request)
    try:
        payload = validate_ingest_payload(json.loads(raw))
        message, duplicate = store.ingest(
            raw_body=raw,
            authorization=authorization,
            device_id=x_device_id,
            timestamp=x_timestamp,
            nonce=x_nonce,
            signature=x_signature,
            idempotency_key=x_idempotency_key,
            payload=payload,
            request_hash=hashlib.sha256(raw).hexdigest(),
            source_address=_client_ip(request),
        )
    except InvalidDeviceCredential as exc:
        raise RelayError(
            401,
            "invalid_device_token",
            "Device credential is invalid, replayed, or revoked",
        ) from exc
    except IdempotencyConflict as exc:
        raise RelayError(
            409,
            "idempotency_conflict",
            "Idempotency key was already used with a different request body",
        ) from exc
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise RelayError(422, "invalid_message", str(exc)) from exc
    if not duplicate:
        otp_event = store.get_otp_delivery(message.id)
        if otp_event:
            await otp_broker.publish(otp_event)
        await _publish_admin_message(message)
    return JSONResponse(status_code=200 if duplicate else 201, content={"accepted": True, "duplicate": duplicate, "message_id": str(message.id)})


@router.post("/otp/claim")
async def claim_otp(
    request: Request,
    payload: dict[str, Any],
    authorization: str | None = Header(default=None),
) -> dict[str, Any]:
    _authenticate_script_token(_script_token_from_authorization(authorization), _client_ip(request))
    raw_phone_number = payload.get("phone_number")
    if not isinstance(raw_phone_number, str) or not raw_phone_number.strip():
        raise RelayError(422, "phone_number_required", "phone_number is required for OTP claim")
    try:
        phone_number = normalize_phone_number(raw_phone_number)
        device_id = UUID(payload["device_id"]) if payload.get("device_id") else None
    except (TypeError, ValueError) as exc:
        raise RelayError(422, "invalid_claim_filter", "phone_number or device_id is invalid") from exc
    try:
        otp = store.claim(
            device_id=device_id,
            phone_number=phone_number,
            sender=payload.get("sender"),
            keyword=payload.get("keyword"),
        )
    except (LookupError, ValueError) as exc:
        raise RelayError(404, "otp_not_available", "No available OTP matched the filters") from exc
    message = store.get_message(otp.message_id)
    if not message:
        raise RelayError(404, "message_not_found", "Source message no longer exists")
    return {
        "otp_id": str(otp.id),
        "code": otp.code,
        "sender": message.sender,
        "message_id": str(message.id),
        "created_at": message.created_at.isoformat(),
        "expires_at": otp.expires_at.isoformat(),
    }


@router.get("/otp/claim.txt", response_class=PlainTextResponse)
async def claim_otp_text(
    request: Request,
    phone_number: str | None = None,
    sender: str | None = None,
    keyword: str | None = None,
    device_id: UUID | None = None,
    authorization: str | None = Header(default=None),
) -> PlainTextResponse:
    _authenticate_script_token(_script_token_from_authorization(authorization), _client_ip(request))
    if not isinstance(phone_number, str) or not phone_number.strip():
        raise RelayError(422, "phone_number_required", "phone_number is required for OTP claim")
    try:
        phone_number = normalize_phone_number(phone_number)
    except ValueError as exc:
        raise RelayError(422, "invalid_claim_filter", "phone_number is invalid") from exc
    try:
        otp = store.claim(
            device_id=device_id,
            phone_number=phone_number,
            sender=sender,
            keyword=keyword,
        )
    except (LookupError, ValueError) as exc:
        raise RelayError(404, "otp_not_available", "No available OTP matched the filters") from exc
    return PlainTextResponse(otp.code)


@router.get("/admin/messages")
async def list_messages(
    phone_number: str | None = None,
    device_id: UUID | None = None,
    sim_slot: int | None = None,
    sender: str | None = None,
    keyword: str | None = None,
    identity_status: str | None = None,
    otp_status: str | None = None,
    read: bool | None = None,
    created_after: datetime | None = None,
    after_id: UUID | None = None,
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    x_admin_token: str | None = Header(default=None),
) -> list[dict[str, Any]]:
    require_admin(x_admin_token)
    if identity_status not in {None, "resolved", "unresolved", "conflict"}:
        raise RelayError(422, "invalid_filter", "Unsupported receiving identity status")
    if otp_status not in {None, "available", "claimed", "expired"}:
        raise RelayError(422, "invalid_filter", "Unsupported OTP status")
    if (created_after is None) != (after_id is None):
        raise RelayError(
            422,
            "invalid_filter",
            "created_after and after_id must be provided together",
        )
    if created_after is not None and (
        created_after.tzinfo is None or created_after.utcoffset() is None
    ):
        raise RelayError(422, "invalid_filter", "created_after must include a timezone")
    try:
        messages = store.list_messages(
            phone_number=phone_number,
            device_id=device_id,
            sim_slot=sim_slot,
            sender=sender,
            keyword=keyword,
            identity_status=identity_status,
            otp_status=otp_status,
            read=read,
            created_after=created_after,
            after_id=after_id,
            limit=limit,
            offset=offset,
        )
    except ValueError as exc:
        raise RelayError(422, "invalid_filter", str(exc)) from exc
    return [_serialize_message(message) for message in messages]


@router.post("/admin/messages/{message_id}/read")
async def mark_message_read(
    message_id: UUID,
    x_admin_token: str | None = Header(default=None),
) -> dict[str, Any]:
    require_admin(x_admin_token)
    try:
        return _serialize_message(store.set_message_read(message_id, read=True))
    except KeyError as exc:
        raise RelayError(404, "message_not_found", "Message not found") from exc


@router.post("/admin/messages/{message_id}/unread")
async def mark_message_unread(
    message_id: UUID,
    x_admin_token: str | None = Header(default=None),
) -> dict[str, Any]:
    require_admin(x_admin_token)
    try:
        return _serialize_message(store.set_message_read(message_id, read=False))
    except KeyError as exc:
        raise RelayError(404, "message_not_found", "Message not found") from exc


@router.delete("/admin/messages/{message_id}", status_code=204)
async def delete_message(
    message_id: UUID,
    x_admin_token: str | None = Header(default=None),
) -> None:
    require_admin(x_admin_token)
    try:
        store.delete_message(message_id)
    except KeyError as exc:
        raise RelayError(404, "message_not_found", "Message not found") from exc


@router.post("/admin/messages/bulk-delete")
async def bulk_delete_messages(
    payload: Any = Body(...),
    x_admin_token: str | None = Header(default=None),
) -> dict[str, int]:
    require_admin(x_admin_token)
    if not isinstance(payload, dict) or not isinstance(payload.get("message_ids"), list):
        raise RelayError(422, "invalid_message_ids", "message_ids must be an array")
    raw_ids = payload["message_ids"]
    if not raw_ids or len(raw_ids) > 500 or any(not isinstance(value, str) for value in raw_ids):
        raise RelayError(422, "invalid_message_ids", "message_ids must contain 1 to 500 UUIDs")
    try:
        message_ids = [UUID(value) for value in raw_ids]
    except ValueError as exc:
        raise RelayError(422, "invalid_message_ids", "message_ids must contain valid UUIDs") from exc
    return {"deleted": store.delete_messages(message_ids)}


@router.get("/admin/otps")
async def list_otps(x_admin_token: str | None = Header(default=None)) -> list[dict[str, Any]]:
    require_admin(x_admin_token)
    return [{"id": str(o.id), "message_id": str(o.message_id), "status": o.status, "expires_at": o.expires_at.isoformat()} for o in store.list_otps()]


@router.post("/admin/retention/run")
async def run_retention(x_admin_token: str | None = Header(default=None)) -> dict[str, int]:
    require_admin(x_admin_token)
    return {"redacted_messages": store.run_retention(settings.retention_days)}


@router.post("/admin/api-clients", status_code=201)
async def create_api_client(x_admin_token: str | None = Header(default=None)) -> dict[str, str]:
    require_admin(x_admin_token)
    return {"token": store.create_api_client()}


@router.get("/admin/api-clients")
async def list_api_clients(
    x_admin_token: str | None = Header(default=None),
) -> dict[str, list[dict[str, object]]]:
    require_admin(x_admin_token)
    return {"clients": store.list_api_clients()}
