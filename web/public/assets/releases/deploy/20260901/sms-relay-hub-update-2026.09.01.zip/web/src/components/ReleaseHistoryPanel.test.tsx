import { render, screen } from "@testing-library/react";
import { expect, test } from "vitest";

import type { ReleaseEntry } from "../adminApi";
import { ReleaseHistoryPanel } from "./ReleaseHistoryPanel";


const releases: ReleaseEntry[] = [
  {
    platform: "android",
    channel: "stable",
    version_code: 12,
    version_name: "1.0.11",
    published_at: "2026-09-01T05:12:06Z",
    min_sdk: 26,
    mandatory: false,
    notes: "Android collector update",
    size_bytes: 2211177,
    sha256: "a".repeat(64),
    signer_sha256: "b".repeat(64),
    download_url: "/assets/releases/android/12/Relay-SMS-Forwarder-1.0.11.apk",
  },
  {
    platform: "root",
    channel: "stable",
    version_code: 307,
    version_name: "0.3.7",
    published_at: "2026-09-01T06:00:00Z",
    min_sdk: 21,
    mandatory: false,
    notes: "Root module update",
    size_bytes: 1200000,
    sha256: "c".repeat(64),
    signer_sha256: "d".repeat(64),
    download_url: "/assets/releases/root/307/relay-root-0.3.7.zip",
  },
  {
    platform: "deploy",
    channel: "stable",
    version_code: 20260901,
    version_name: "2026.09.01",
    published_at: "2026-09-01T07:00:00Z",
    min_sdk: 21,
    mandatory: false,
    notes: "Deployment package",
    size_bytes: 38000000,
    sha256: "e".repeat(64),
    signer_sha256: "f".repeat(64),
    download_url: "/assets/releases/deploy/20260901/sms-relay-hub-deploy.zip",
  },
];


test("renders Android, Root and deployment release histories", () => {
  render(<ReleaseHistoryPanel releases={releases} />);

  expect(screen.getByText("Android 1.0.11")).toBeInTheDocument();
  expect(screen.getByText("Root 0.3.7")).toBeInTheDocument();
  expect(screen.getByText("部署包 2026.09.01")).toBeInTheDocument();
  expect(screen.getByRole("link", { name: "下载 Android 1.0.11" })).toHaveAttribute(
    "href",
    releases[0].download_url,
  );
});
