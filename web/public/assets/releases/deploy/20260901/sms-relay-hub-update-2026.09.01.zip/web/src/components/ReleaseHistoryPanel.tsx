import { Download } from "lucide-react";

import type { ReleaseEntry } from "../adminApi";


type ReleaseHistoryPanelProps = {
  releases: ReleaseEntry[];
};

const platformLabels: Record<ReleaseEntry["platform"], string> = {
  android: "Android",
  manager: "管理端",
  root: "Root",
  deploy: "部署包",
};

function sizeLabel(size: number): string {
  return (size / 1024 / 1024).toFixed(1) + " MB";
}

export function ReleaseHistoryPanel({ releases }: ReleaseHistoryPanelProps) {
  const ordered = [...releases].sort((left, right) => right.published_at.localeCompare(left.published_at));
  return (
    <section className="release-history-panel" aria-labelledby="release-history-title">
      <div className="section-heading">
        <div>
          <h2 id="release-history-title">版本历史</h2>
          <span className="section-count">Android、管理端、Root 模块和部署包</span>
        </div>
      </div>
      <div className="release-history-list">
        {ordered.length === 0 ? <p className="empty-state">暂无发布历史</p> : ordered.map((release) => {
          const title = platformLabels[release.platform] + " " + release.version_name;
          return (
            <article key={release.platform + "-" + release.version_code}>
              <div>
                <strong>{title}</strong>
                <span>{new Date(release.published_at).toLocaleString()} · {sizeLabel(release.size_bytes)}</span>
                <p>{release.notes}</p>
                <code>SHA-256 {release.sha256}</code>
              </div>
              <a className="secondary-button" href={release.download_url} aria-label={"下载 " + title}>
                <Download size={15} />下载
              </a>
            </article>
          );
        })}
      </div>
    </section>
  );
}
