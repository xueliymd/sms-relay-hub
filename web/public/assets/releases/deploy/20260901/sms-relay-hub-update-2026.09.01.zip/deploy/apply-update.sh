#!/bin/sh

set -eu
umask 077

TARGET=${1:-}
if [ -z "$TARGET" ]; then
    printf '%s\n' 'usage: sh deploy/apply-update.sh /absolute/current/install/path [backup-root]' >&2
    exit 2
fi
case "$TARGET" in
    /*) ;;
    *) printf '%s\n' 'target path must be absolute' >&2; exit 2 ;;
esac
if [ "$TARGET" = / ] || [ ! -f "$TARGET/deploy/compose.yml" ] || [ ! -f "$TARGET/deploy/.env" ]; then
    printf '%s\n' 'target is not a valid Relay Hub installation' >&2
    exit 2
fi
TARGET=$(CDPATH= cd "$TARGET" && pwd)

SCRIPT_DIR=$(CDPATH= cd "$(dirname "$0")" && pwd)
SOURCE_ROOT=$(CDPATH= cd "$SCRIPT_DIR/.." && pwd)
case "$SOURCE_ROOT" in
    "$TARGET"|"$TARGET"/*) printf '%s\n' 'extract the update package outside the active installation' >&2; exit 2 ;;
esac

BACKUP_ROOT=${2:-"$(dirname "$TARGET")/relay-update-history"}
case "$BACKUP_ROOT" in
    "$TARGET"|"$TARGET"/*) printf '%s\n' 'backup root must be outside the active installation' >&2; exit 2 ;;
esac
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
BACKUP_DIR="$BACKUP_ROOT/relay-backup-$STAMP"
mkdir -p "$BACKUP_DIR"

compose() {
    docker compose --env-file "$TARGET/deploy/.env" -f "$TARGET/deploy/compose.yml" "$@"
}

set -a
. "$TARGET/deploy/.env"
set +a
POSTGRES_USER=${POSTGRES_USER:-sms_relay}
POSTGRES_DB=${POSTGRES_DB:-sms_relay}

tar -czf "$BACKUP_DIR/source.tar.gz" -C "$TARGET" .
cp "$TARGET/deploy/.env" "$BACKUP_DIR/deploy.env"
if [ -d "$TARGET/web/public/assets/releases" ]; then
    cp -a "$TARGET/web/public/assets/releases" "$BACKUP_DIR/release-store"
fi
compose exec -T postgres pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc > "$BACKUP_DIR/database.dump"

rollback() {
    status=$?
    trap - EXIT HUP INT TERM
    if [ "$status" -ne 0 ]; then
        printf '%s\n' 'update failed; restoring previous source and configuration' >&2
        rm -rf "$TARGET/backend" "$TARGET/clients" "$TARGET/deploy" "$TARGET/web"
        rm -f "$TARGET/README.md" "$TARGET/.dockerignore"
        tar -xzf "$BACKUP_DIR/source.tar.gz" -C "$TARGET"
        compose up --build -d || true
    fi
    exit "$status"
}
trap rollback EXIT HUP INT TERM

compose stop app caddy
rm -rf "$TARGET/backend" "$TARGET/clients" "$TARGET/deploy" "$TARGET/web"
rm -f "$TARGET/README.md" "$TARGET/.dockerignore"
cp -a "$SOURCE_ROOT/backend" "$SOURCE_ROOT/clients" "$SOURCE_ROOT/deploy" "$SOURCE_ROOT/web" "$TARGET/"
cp "$SOURCE_ROOT/README.md" "$SOURCE_ROOT/.dockerignore" "$TARGET/"
cp "$BACKUP_DIR/deploy.env" "$TARGET/deploy/.env"
if [ -d "$BACKUP_DIR/release-store" ]; then
    mkdir -p "$TARGET/web/public/assets"
    rm -rf "$TARGET/web/public/assets/releases"
    cp -a "$BACKUP_DIR/release-store" "$TARGET/web/public/assets/releases"
fi

compose up --build -d
compose ps
trap - EXIT HUP INT TERM
printf '%s\n' "update complete; backup retained at $BACKUP_DIR"
