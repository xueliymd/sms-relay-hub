# Compose 部署

## 配置

在服务器上只上传发布包，不上传工作区和 `deploy/.env`：

```powershell
pwsh -NoProfile -File deploy/package.ps1
```

把生成的 `deploy/dist/sms-relay-hub-deploy.zip` 上传到服务器后解压，再在服务器上执行下面的初始化和 Compose 命令。

```powershell
pwsh -File deploy/bootstrap.ps1
```

初始化脚本只在缺少值时生成 `ADMIN_PASSWORD`、`ADMIN_TOKEN`、`DATA_ENCRYPTION_KEY`、`POSTGRES_PASSWORD` 和 `DATABASE_URL`，不会覆盖已有的非空凭据。首次生成管理员密码或恢复令牌时，会在终端打印管理员用户名、密码和恢复令牌；恢复令牌保留给维护脚本使用，管理台不提供填写入口。重复执行不会再次打印已有密码。生成的 `deploy/.env` 不要提交到 Git。`DATA_ENCRYPTION_KEY` 是 32 字节随机值的 base64url 编码，数据库密码会写入连接串并自动 URL 编码。

管理台只使用初始化输出的管理员用户名和密码登录；登录后可在右上角账号设置中修改用户名和密码，浏览器会自动保存短期会话。恢复令牌不在管理台显示或填写，但后端兼容入口仍可供维护脚本使用。Android/Root/iPhone/Ve 设备使用设备页创建时显示一次的 HMAC/Bearer 凭据；合宙 724 在设备页选择“合宙 724 取码”后显示一次脚本 API 令牌；普通外部脚本仍在总览的“接口凭据”中创建独立 API Client Bearer Token。令牌用途不同，不能互换。

合宙 Air724 取码脚本连接同一站点的 `/api/v1/ws/otp`。Caddy 的 `reverse_proxy` 会自动转发 WebSocket Upgrade，不需要单独开放一个 WebSocket 端口；HTTP 站点对应 `ws://`，HTTPS 站点对应 `wss://`。

当前实时 OTP broker 保存在应用进程内存中，因此应用固定使用 `--workers 1`。在接入 Redis 或 PostgreSQL 通知 broker 前，不要横向扩容应用 worker，否则不同进程中的 WebSocket 连接无法收到彼此创建的 OTP 事件。PostgreSQL 仍是消息和取码记录的持久数据源，HTTP Claim 可用于断线恢复。

端口默认值是宿主机 HTTP `39300`、宿主机 HTTPS `39301`、容器内部应用 `39200`；应用容器不直接暴露到公网。部署前可在 `.env` 自定义宿主机 `HTTP_PORT`、`HTTPS_PORT` 和应用容器内部 `APP_PORT`。Compose 的映射关系是：宿主机 `39300 -> Caddy 容器 80`、宿主机 `39301 -> Caddy 容器 443`、Caddy 容器再转发到应用容器 `39200`。`RELAY_SITE=:80` 是当前没有域名时的纯 HTTP/IP 模式，即使宿主机端口改成别的值也保持 `:80` 不变，手机使用 `http://服务器IP:39300`。域名解析完成后，把 `RELAY_SITE` 改为你自己的真实域名，Caddy 才会为该域名申请 HTTPS 证书。

公开手机接入时，`RELAY_SITE` 必须是已解析到服务器的真实域名，由 Caddy 自动申请可信证书。HTTP 私网测试不要求域名或 HTTPS。

## 启停

```powershell
docker compose --env-file deploy/.env -f deploy/compose.yml up --build -d
docker compose --env-file deploy/.env -f deploy/compose.yml ps
docker compose --env-file deploy/.env -f deploy/compose.yml logs --tail 100 app
docker compose --env-file deploy/.env -f deploy/compose.yml down
```

应用容器为只读根文件系统，启动时先执行 Alembic 迁移。生产数据库只由显式 `DATABASE_URL` 指向 PostgreSQL；持久数据固定保存在命名卷 `postgres_data`，不会读取工作区中的 `.db`、`debug/preview.db` 或客户端本地队列。Caddy 数据保存在 `caddy_data` 和 `caddy_config`。

部署后先检查公开的 `/api/v1/health`，再从管理台登录后检查 `/api/v1/admin/runtime`：`database_backend` 必须是 `postgresql`。`database_fingerprint` 是排除密码后的数据库连接身份短哈希，只用于比对是否连到预期实例，不会回显连接串或密码。

Air724 部署验收还应检查：浏览器或脚本可以连接 `ws(s)://你的站点/api/v1/ws/otp`；发送 `auth` 后收到 `auth_ok`；发送 `subscribe` 后收到 `subscribed`；新短信进入平台后收到 `otp`。真实 Air724/Air724U 仍需使用旧版 Lua 5.1 固件完成硬件验收。

## 备份与恢复

备份只应写入服务器受控目录，且文件权限应限制为管理员：

```powershell
docker compose --env-file deploy/.env -f deploy/compose.yml exec -T postgres pg_dump -U sms_relay -d sms_relay -Fc > relay-backup.dump
```

恢复前先停止 `app`，在独立测试环境验证备份，然后使用 `pg_restore --clean --if-exists` 恢复。`DATA_ENCRYPTION_KEY` 必须与备份时一致，否则敏感字段无法解密；该密钥应和数据库备份分开保管。

## 更新

```powershell
docker compose --env-file deploy/.env -f deploy/compose.yml build --pull app
docker compose --env-file deploy/.env -f deploy/compose.yml up -d
```

每次更新都会先运行幂等 Alembic 迁移。更新后检查 `/api/v1/health`、管理端设备列表和一组脱敏协议 smoke。
