param(
    [string]$Output = "deploy/dist/sms-relay-hub-deploy.zip"
)

$ErrorActionPreference = "Stop"
$repositoryRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$resolvedOutput = if ([IO.Path]::IsPathRooted($Output)) { $Output } else { Join-Path $repositoryRoot $Output }
$outputDirectory = Split-Path -Parent $resolvedOutput
New-Item -ItemType Directory -Force -Path $outputDirectory | Out-Null
if (Test-Path -LiteralPath $resolvedOutput) { Remove-Item -LiteralPath $resolvedOutput -Force }

$staging = Join-Path ([IO.Path]::GetTempPath()) ("sms-relay-deploy-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $staging | Out-Null
$packagedCatalog = $null
try {
    $publicAssets = Join-Path $repositoryRoot "web/public"
    if (-not (Test-Path -LiteralPath $publicAssets -PathType Container)) { throw "web/public download library is missing" }
    foreach ($relative in @("backend", "clients/script_api", "clients/air724", "deploy", "web", "README.md", ".dockerignore")) {
        Copy-Item -LiteralPath (Join-Path $repositoryRoot $relative) -Destination (Join-Path $staging $relative) -Recurse -Force
    }

    foreach ($relative in @(
        "web/node_modules",
        "web/dist",
        "backend/.venv",
        "backend/.mypy_cache",
        "backend/.pytest_cache",
        "backend/.ruff_cache",
        "deploy/.env",
        "deploy/dist",
        "manager-android"
    )) {
        $path = Join-Path $staging $relative
        if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Recurse -Force }
    }

    $legacyDownloads = Join-Path $staging "web/public/downloads"
    if (Test-Path -LiteralPath $legacyDownloads) {
        Remove-Item -LiteralPath $legacyDownloads -Recurse -Force
    }

    $releaseRoot = Join-Path $staging "web/public/assets/releases"
    $deployReleaseRoot = Join-Path $releaseRoot "deploy"
    if (Test-Path -LiteralPath $deployReleaseRoot) {
        Remove-Item -LiteralPath $deployReleaseRoot -Recurse -Force
    }

    $catalogPath = Join-Path $releaseRoot "release-catalog.json"
    $catalog = Get-Content -LiteralPath $catalogPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $includedReleases = @(
        $catalog.releases |
            Where-Object { $_.platform -ne "deploy" } |
            Group-Object platform |
            ForEach-Object {
                $_.Group | Sort-Object { [int]$_.version_code } -Descending | Select-Object -First 2
            }
    )
    $catalog.releases = $includedReleases
    $catalog | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $catalogPath -Encoding UTF8
    $packagedCatalog = $catalog

    $publicRoot = Join-Path $staging "web/public"
    $includedUrls = @($includedReleases | ForEach-Object { $_.download_url })
    Get-ChildItem -LiteralPath $releaseRoot -Recurse -File | ForEach-Object {
        $relative = $_.FullName.Substring($publicRoot.Length + 1).Replace("\", "/")
        if ($_.Name -ne "release-catalog.json" -and "/$relative" -notin $includedUrls) {
            Remove-Item -LiteralPath $_.FullName -Force
        }
    }

    Get-ChildItem -LiteralPath (Join-Path $publicRoot "assets/downloads") -File |
        Where-Object { $_.Name -like "sms-relay-root-module-*.zip" } |
        Remove-Item -Force

    Get-ChildItem -LiteralPath $staging -Recurse -Directory -Force |
        Where-Object { $_.Name -in @("__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache") } |
        Sort-Object FullName -Descending |
        Remove-Item -Recurse -Force
    Get-ChildItem -LiteralPath $staging -Recurse -File -Force |
        Where-Object { $_.Name -match "\.(db|sqlite|sqlite3)(-(wal|shm))?$" -or $_.Extension -eq ".pyc" } |
        Remove-Item -Force

    Compress-Archive -Path (Join-Path $staging "*") -DestinationPath $resolvedOutput -CompressionLevel Optimal
}
finally {
    if (Test-Path -LiteralPath $staging) { Remove-Item -LiteralPath $staging -Recurse -Force }
}

Add-Type -AssemblyName System.IO.Compression
$archive = [IO.Compression.ZipFile]::OpenRead($resolvedOutput)
try {
    # Compress-Archive/.NET report entry names with the Windows separator, so
    # normalise to forward slashes before matching. Without this every check
    # below silently passes, including the secret and database guards.
    $names = @($archive.Entries | ForEach-Object { $_.FullName.Replace('\', '/') })
    $requiredEntries = @(
        "backend/pyproject.toml",
        "deploy/compose.yml",
        "deploy/bootstrap.ps1",
        "deploy/preflight.ps1",
        "deploy/preflight.sh",
        "web/package.json",
        "web/public/assets/downloads/air724-otp-websocket.lua",
        "web/public/assets/downloads/air724-otp-websocket/main.lua",
        "web/public/assets/downloads/air724-otp-websocket/config.example.lua",
        "web/public/assets/downloads/air724-otp-websocket/README.md",
        "web/public/assets/downloads/air724-mqtt-ingest.lua",
        "clients/script_api/otp_client.py",
        "clients/script_api/README.md",
        "clients/air724/main.lua",
        "clients/air724/config.example.lua",
        "clients/air724/README.md",
        "backend/app/mqtt_bridge.py",
        "clients/air724/mqtt_ingest.lua",
        ".dockerignore"
    )
    $requiredEntries += "web/public/assets/releases/release-catalog.json"
    foreach ($required in $requiredEntries) {
        if ($names -notcontains $required) { throw "deployment archive entry missing: $required" }
    }
    foreach ($forbidden in @(
        "deploy/.env",
        "deploy/dist",
        "web/node_modules",
        "backend/.venv",
        "backend/.mypy_cache",
        "backend/.pytest_cache",
        "backend/.ruff_cache",
        "manager-android",
        "web/public/downloads"
    )) {
        if ($names | Where-Object { $_ -eq $forbidden -or $_.StartsWith("$forbidden/") }) {
            throw "deployment archive contains local runtime or secret path: $forbidden"
        }
    }
    if ($names | Where-Object { $_ -match "(^|/)(__pycache__|\.pytest_cache|\.mypy_cache|\.ruff_cache)(/|$)" -or $_ -match "\.(db|sqlite|sqlite3)(-(wal|shm))?$" -or $_ -match "\.pyc$" }) {
        throw "deployment archive contains local cache or database artifacts"
    }
    $forbiddenArtifactPatterns = @("*.p12", "*.jks", "*.keystore", "*signing.properties")
    if ($names | Where-Object {
        $leafName = Split-Path -Leaf $_
        $_ -match "(^|/)(logs?|screenshots?|temp|tmp)(/|$)" -or
        $_ -match "(^|/)(app-)?debug\.apk$" -or
        $_ -match "-debug\.apk$" -or
        ($forbiddenArtifactPatterns | Where-Object { $leafName -like $_ })
    }) {
        throw "deployment archive contains debug, temporary, or signing artifacts"
    }
    # Non-ASCII entry names get stored in the OS codepage by Compress-Archive and
    # decode to invalid UTF-8 on Linux, which breaks Docker build-context transfer
    # (grpc: string field contains invalid UTF-8). Keep every packaged path ASCII.
    $nonAscii = $names | Where-Object { ($_.ToCharArray() | Where-Object { [int]$_ -gt 127 }).Count -gt 0 }
    if ($nonAscii) {
        throw "deployment archive contains non-ASCII path (breaks docker build): $($nonAscii -join ', ')"
    }
    if ($null -eq $packagedCatalog) { throw "packaged release catalog is missing" }
    $catalog = $packagedCatalog
    if (@($catalog.releases | Where-Object { $_.platform -eq "deploy" })) {
        throw "deployment archive must not embed container deploy or update packages"
    }
    foreach ($release in @($catalog.releases)) {
        $releaseEntry = "web/public$($release.download_url)"
        if ($names -notcontains $releaseEntry) {
            throw "deployment archive is missing catalog artifact: $releaseEntry"
        }
    }
    if ($names | Where-Object { $_ -match "(^|/)sms-relay-hub-(deploy|update)(-.*)?\.zip$" }) {
        throw "deployment archive contains an embedded container deployment or update package"
    }
}
finally { $archive.Dispose() }

Get-Item -LiteralPath $resolvedOutput | Select-Object FullName, Length
