import pytest
from fastapi.testclient import TestClient

from app.core.config import settings
from app.services.store import store


def test_database_identity_is_available_only_to_an_authenticated_admin(
    client: TestClient,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(settings, "platform_version", "1.1.0")
    monkeypatch.setattr(settings, "public_base_url", "https://sms.example.test")
    monkeypatch.setattr(settings, "relay_site", "sms.example.test")
    monkeypatch.setattr(settings, "http_port", 39300)
    monkeypatch.setattr(settings, "https_port", 39301)
    monkeypatch.setattr(settings, "app_port", 39200)
    unauthenticated = client.get("/api/v1/admin/runtime")
    assert unauthenticated.status_code == 401

    response = client.get(
        "/api/v1/admin/runtime",
        headers={"X-Admin-Token": settings.admin_token},
    )
    assert response.status_code == 200
    payload = response.json()
    assert payload["database_backend"] == "sqlite"
    assert len(payload["database_fingerprint"]) == 12
    assert payload["platform_version"] == "1.1.0"
    assert payload["public_base_url"] == "https://sms.example.test"
    assert payload["http_port"] == 39300
    assert payload["https_port"] == 39301
    assert payload["app_port"] == 39200
    assert payload["https_enabled"] is True
    assert payload["services"] == {
        "app": "healthy",
        "database": "healthy",
        "caddy": "configured",
    }
    assert payload["server_time"].endswith("+00:00")
    assert "database_url" not in payload
    assert "admin_token" not in str(payload).lower()
    assert "data_encryption_key" not in str(payload).lower()


def test_database_fingerprint_ignores_password_rotation() -> None:
    original_url = store.database_url
    try:
        store.database_url = "postgresql+psycopg://relay:first-secret@db:5432/messages"
        first = store.database_fingerprint()
        store.database_url = "postgresql+psycopg://relay:second-secret@db:5432/messages"
        second = store.database_fingerprint()
        store.database_url = "postgresql+psycopg://relay:second-secret@db:5432/other"
        other_database = store.database_fingerprint()
    finally:
        store.database_url = original_url

    assert first == second
    assert first != other_database
