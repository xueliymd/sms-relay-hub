#!/usr/bin/env sh
set -eu

ENV_FILE=${1:-"$(dirname "$0")/.env"}
SKIP_DOCKER=${SKIP_DOCKER:-0}
SKIP_DNS=${SKIP_DNS:-0}
COMPOSE_FILE=$(dirname "$0")/compose.yml
errors=0

get_value() {
    key=$1
    sed -n "s/^${key}=//p" "$ENV_FILE" | tail -n 1 | sed 's/[[:space:]]*$//'
}

error() {
    printf 'ERROR: %s\n' "$1" >&2
    errors=$((errors + 1))
}

warning() {
    printf 'WARNING: %s\n' "$1" >&2
}

if [ ! -f "$ENV_FILE" ]; then
    error "env file not found: $ENV_FILE"
else
    for key in ADMIN_USERNAME ADMIN_PASSWORD ADMIN_TOKEN DATA_ENCRYPTION_KEY POSTGRES_PASSWORD DATABASE_URL RELAY_SITE HTTP_PORT HTTPS_PORT APP_PORT; do
        value=$(get_value "$key")
        [ -n "$value" ] || error "$key is missing or empty"
    done
fi

is_port() {
    case "$1" in
        ''|*[!0-9]*) return 1 ;;
    esac
    [ "$1" -ge 1 ] && [ "$1" -le 65535 ]
}

http_port=$(get_value HTTP_PORT || true)
https_port=$(get_value HTTPS_PORT || true)
app_port=$(get_value APP_PORT || true)
is_port "$http_port" || error 'HTTP_PORT must be an integer from 1 to 65535'
is_port "$https_port" || error 'HTTPS_PORT must be an integer from 1 to 65535'
is_port "$app_port" || error 'APP_PORT must be an integer from 1 to 65535'
[ -n "$http_port" ] && [ "$http_port" != "$https_port" ] || error 'HTTP_PORT and HTTPS_PORT must be different'
if [ -n "$app_port" ] && { [ "$app_port" = "$http_port" ] || [ "$app_port" = "$https_port" ]; }; then
    warning 'APP_PORT is an internal container port; it matches a host port. This is valid, but a different value is easier to diagnose.'
fi

site=$(get_value RELAY_SITE || true)
relay_domain=$(get_value RELAY_DOMAIN || true)
site_host=''
case "$site" in
    :*)
        site_port=${site#:}
        is_port "$site_port" || error 'RELAY_SITE listen port is invalid'
        [ -n "$relay_domain" ] || warning 'RELAY_DOMAIN is empty; only the HTTP/IP entry is enabled.'
        ;;
    '')
        ;;
    *[/:]*)
        error 'RELAY_SITE must be :PORT or a DNS hostname without scheme/path'
        ;;
    *)
        [ -n "$relay_domain" ] || warning 'RELAY_SITE contains a domain for backward compatibility; prefer RELAY_SITE=:80 plus RELAY_DOMAIN.'
        ;;
esac

if [ -n "$relay_domain" ]; then
    case "$relay_domain" in
        *[!A-Za-z0-9.-]*|.*|*.|*..*)
            error 'RELAY_DOMAIN must be a DNS hostname without scheme, path, or port'
            ;;
        *)
            site_host=$relay_domain
            ;;
    esac
    [ "$site" = ':80' ] || error 'RELAY_SITE must stay :80 in dual mode; put the DNS name in RELAY_DOMAIN'
    [ "$https_port" = '443' ] || warning "HTTPS_PORT is $https_port; the domain URL must include this port unless it is 443."
fi

public_base_url=$(get_value PUBLIC_BASE_URL || true)
if [ -z "$public_base_url" ]; then
    warning 'PUBLIC_BASE_URL is empty; clients must use the manually configured server address.'
else
    case "$public_base_url" in
        http://*|https://*) ;;
        *) error 'PUBLIC_BASE_URL must start with http:// or https://' ;;
    esac
    case "$public_base_url" in
        *'@'*|*'?'*|*'#'*|*/[!/]*) error 'PUBLIC_BASE_URL must be an origin without credentials, path, query, or fragment' ;;
    esac
    case "$public_base_url" in
        http://*) warning 'PUBLIC_BASE_URL uses HTTP; use HTTPS for public iPhone and admin traffic.' ;;
    esac
fi

if [ -n "$site_host" ] && [ "$SKIP_DNS" != '1' ] && command -v getent >/dev/null 2>&1; then
    getent ahosts "$site_host" >/dev/null 2>&1 || warning "DNS did not resolve $site_host from this machine"
fi

compose_project_name=$(get_value COMPOSE_PROJECT_NAME || true)
[ -n "$compose_project_name" ] || warning 'COMPOSE_PROJECT_NAME is empty; set a unique name for each instance.'

if [ "$SKIP_DOCKER" != '1' ]; then
    if ! command -v docker >/dev/null 2>&1; then
        warning 'docker command is not available; skipped docker compose config validation'
    elif ! docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" config --quiet >/dev/null 2>&1; then
        error 'docker compose config validation failed'
    fi
fi

if command -v ss >/dev/null 2>&1; then
    for port in "$http_port" "$https_port"; do
        if is_port "$port" && ss -ltnH 2>/dev/null | awk -v port=":$port" '$4 ~ port"$" {found=1} END {exit !found}'; then
            warning "host port $port is already listening; verify it belongs to this Compose instance"
        fi
    done
fi

[ "$errors" -eq 0 ] || exit 1
printf 'Preflight passed: %s\n' "$ENV_FILE"
printf 'Ports: HTTP=%s HTTPS=%s APP=%s\n' "$http_port" "$https_port" "$app_port"
[ -n "$site_host" ] && printf 'HTTPS hostname: %s\n' "$site_host"
