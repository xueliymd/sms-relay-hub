export type AdminDevice = {
  id: string;
  name: string;
  client_type: "android_app" | "root_module" | "ios_shortcut" | "ve_tweak" | "air724" | "air724_mqtt";
  auth_kind: "hmac" | "bearer" | "script_api";
  active: boolean;
  online?: boolean;
  last_seen_at: string | null;
  client_instance_id?: string | null;
  client_version?: string | null;
  client_mode?: string | null;
  runtime_updated_at?: string | null;
  credential_reuse_warning?: boolean;
  duplicate_collection_warning?: boolean;
};

export type AdminMessage = {
  id: string;
  device_id: string;
  client_message_id: string;
  received_at: string;
  created_at?: string;
  message_date?: string | null;
  sender: string;
  body: string | null;
  source: string;
  sim_slot: number | null;
  subscription_id: number | null;
  receiving_phone_masked: string | null;
  receiving_identity_status: "resolved" | "unresolved" | "conflict";
  otp_status: "available" | "claimed" | "expired" | null;
  otp_code?: string | null;
  read_at: string | null;
  metadata: Record<string, unknown>;
  redacted: boolean;
};

export type RuntimeInfo = {
  database_backend: string;
  database_fingerprint: string;
  platform_version: string;
  public_base_url: string;
  relay_site: string;
  http_port: number;
  https_port: number;
  app_port: number;
  https_enabled: boolean;
  services: Record<string, string>;
  server_time: string;
};

export type ReleaseEntry = {
  platform: "android" | "manager" | "root";
  channel: string;
  version_code: number;
  version_name: string;
  published_at: string;
  min_sdk: number;
  mandatory: boolean;
  notes: string;
  size_bytes: number;
  sha256: string;
  signer_sha256: string | null;
  download_url: string;
};

export type MessageCursor = {
  createdAt: string;
  id: string;
};

export type MessageQueryFilters = {
  deviceId?: string;
  simSlot?: number | null;
  limit?: number;
};

export async function adminRequest<T>(
  path: string,
  token: string,
  init: RequestInit = {},
): Promise<T> {
  const headers: Record<string, string> = {};
  if (init.body) headers["Content-Type"] = "application/json";
  new Headers(init.headers).forEach((value, key) => {
    headers[key] = value;
  });
  headers["X-Admin-Token"] = token;
  const response = await fetch(path, { ...init, headers });
  if (!response.ok) {
    let code = "http_" + response.status;
    try {
      const payload = (await response.json()) as { error?: { code?: string } };
      code = payload.error?.code ?? code;
    } catch {
      code = code;
    }
    throw new Error(code);
  }
  if (response.status === 204) return undefined as T;
  return (await response.json()) as T;
}

export function adminWebSocketUrl(baseUrl: string, path: string): string {
  const origin = new URL(baseUrl || window.location.origin, window.location.origin);
  origin.protocol = origin.protocol === "https:" ? "wss:" : "ws:";
  origin.pathname = path.startsWith("/") ? path : "/" + path;
  origin.search = "";
  origin.hash = "";
  return origin.toString();
}

export function messageCursorQuery(
  cursor: MessageCursor | null,
  filters: MessageQueryFilters = {},
): string {
  const params = new URLSearchParams();
  if (filters.deviceId) params.set("device_id", filters.deviceId);
  if (filters.simSlot !== null && filters.simSlot !== undefined) {
    params.set("sim_slot", String(filters.simSlot));
  }
  if (filters.limit !== undefined) params.set("limit", String(filters.limit));
  if (cursor) {
    params.set("created_after", cursor.createdAt);
    params.set("after_id", cursor.id);
  }
  const query = params.toString();
  return query ? "?" + query : "";
}
