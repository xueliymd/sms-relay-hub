import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_compose_uses_postgres_and_required_runtime_secrets() -> None:
    compose = (ROOT / "deploy" / "compose.yml").read_text(encoding="utf-8")

    assert "  postgres:" in compose
    assert "DATABASE_URL:" in compose
    assert "POSTGRES_PASSWORD:" in compose
    assert "condition: service_healthy" in compose
    assert "STATE_FILE:" not in compose
    assert '"${HTTP_PORT:-39300}:80"' in compose
    assert '"${HTTPS_PORT:-39301}:443"' in compose
    assert '"${HTTPS_PORT:-39301}:443/udp"' in compose
    assert "APP_PORT: ${APP_PORT:-39200}" in compose
    assert '"${APP_PORT:-39200}"' in compose
    assert "os.environ.get('APP_PORT', '39200')" in compose
    assert 'entrypoint: ["python", "-m", "app.mqtt_bridge"]' in compose
    assert "MQTT_BROKER_HOST: ${MQTT_BROKER_HOST:-}" in compose
    assert "RELAY_MQTT_BRIDGE_TOKEN: ${RELAY_MQTT_BRIDGE_TOKEN:-}" in compose


def test_caddy_uses_explicit_http_or_domain_site_without_a_fake_hostname() -> None:
    env_example = (ROOT / "deploy" / ".env.example").read_text(encoding="utf-8")
    bootstrap = (ROOT / "deploy" / "bootstrap.ps1").read_text(encoding="utf-8")
    caddy = (ROOT / "deploy" / "Caddyfile").read_text(encoding="utf-8")
    caddy_domain = (ROOT / "deploy" / "Caddyfile.domain").read_text(encoding="utf-8")
    caddy_entrypoint = (ROOT / "deploy" / "caddy-entrypoint.sh").read_text(encoding="utf-8")
    compose = (ROOT / "deploy" / "compose.yml").read_text(encoding="utf-8")

    assert "RELAY_SITE=:80" in env_example
    assert "RELAY_DOMAIN=" in env_example
    assert "RELAY_SITE = ':80'" in bootstrap
    assert "RELAY_DOMAIN = ''" in bootstrap
    assert ":80 {" in caddy
    assert "import relay_proxy" in caddy
    assert "__RELAY_DOMAIN__" in caddy_domain
    assert "@domain host __RELAY_DOMAIN__" in caddy_domain
    assert "redir @domain https://__RELAY_DOMAIN__{uri}" in caddy_domain
    assert "reverse_proxy app:{$APP_PORT}" in caddy
    assert "RELAY_DOMAIN: ${RELAY_DOMAIN:-}" in compose
    assert "caddy-entrypoint.sh" in compose
    assert "Caddyfile.domain" in compose
    assert 'if [ -z "$domain" ] && [ "${RELAY_SITE:-:80}" != ":80" ]; then' in caddy_entrypoint
    assert 'sed "s/__RELAY_DOMAIN__/$domain/g"' in caddy_entrypoint
    assert "relay.example.com" not in caddy


def test_deployment_documents_keep_caddy_internal_and_host_ports_separate() -> None:
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    deploy_readme = (ROOT / "deploy" / "README.md").read_text(encoding="utf-8")

    assert "不要改成 `:39300`" in readme
    assert "宿主机 `39300 -> Caddy 容器 80`" in deploy_readme
    assert "`RELAY_SITE=:80`" in deploy_readme
    assert "`RELAY_DOMAIN`" in deploy_readme
    assert "两个入口同时可用" in deploy_readme
    assert "改为 `RELAY_SITE=:18080`" not in deploy_readme


def test_deployment_bootstrap_generates_missing_secrets_without_overwriting_existing_values() -> None:
    bootstrap = (ROOT / "deploy" / "bootstrap.ps1").read_text(encoding="utf-8")

    assert "RandomNumberGenerator" in bootstrap
    assert "ADMIN_TOKEN" in bootstrap
    assert "ADMIN_USERNAME" in bootstrap
    assert "ADMIN_PASSWORD" in bootstrap
    assert "DATA_ENCRYPTION_KEY" in bootstrap
    assert "POSTGRES_PASSWORD" in bootstrap
    assert "DATABASE_URL" in bootstrap
    assert "Test-Path -LiteralPath $Path" in bootstrap
    assert "Set-Content -LiteralPath $envFile" in bootstrap
    assert "Do not overwrite" in bootstrap
    assert "APP_PORT = '39200'" in bootstrap
    assert "Generated administrator credentials" in bootstrap
    assert "Recovery token" in bootstrap


def test_deployment_preflight_checks_configuration_and_instance_isolation() -> None:
    powershell = (ROOT / "deploy" / "preflight.ps1").read_text(encoding="utf-8")
    unix = (ROOT / "deploy" / "preflight.sh").read_text(encoding="utf-8")

    for script in (powershell, unix):
        assert "ADMIN_PASSWORD" in script
        assert "DATA_ENCRYPTION_KEY" in script
        assert "HTTP_PORT" in script
        assert "HTTPS_PORT" in script
        assert "APP_PORT" in script
        assert "COMPOSE_PROJECT_NAME" in script
        assert "PUBLIC_BASE_URL" in script
        assert "RELAY_DOMAIN" in script
        assert "docker compose" in script
    assert "Resolve-DnsName" in powershell
    assert "getent ahosts" in unix


def test_compose_passes_admin_login_credentials_to_the_application() -> None:
    compose = (ROOT / "deploy" / "compose.yml").read_text(encoding="utf-8")

    assert "ADMIN_USERNAME: ${ADMIN_USERNAME:?set ADMIN_USERNAME in .env}" in compose
    assert "ADMIN_PASSWORD: ${ADMIN_PASSWORD:?set ADMIN_PASSWORD in .env}" in compose


def test_unix_bootstrap_generates_and_reports_admin_credentials() -> None:
    bootstrap = (ROOT / "deploy" / "bootstrap.sh").read_text(encoding="utf-8")

    assert "set_if_empty ADMIN_USERNAME admin" in bootstrap
    assert "set_if_empty ADMIN_PASSWORD" in bootstrap
    assert "Generated administrator credentials" in bootstrap
    assert "Recovery token" in bootstrap


def test_container_runs_migrations_before_the_api() -> None:
    dockerfile = (ROOT / "deploy" / "Dockerfile").read_text(encoding="utf-8")
    entrypoint = (ROOT / "deploy" / "entrypoint.sh").read_text(encoding="utf-8")
    migration_env = (ROOT / "backend" / "migrations" / "env.py").read_text(encoding="utf-8")

    assert "deploy/entrypoint.sh" in dockerfile
    assert "alembic upgrade head" in entrypoint
    assert "exec uvicorn" in entrypoint
    assert '${APP_PORT:-39200}' in entrypoint
    assert "--workers 1" in entrypoint
    assert 'os.environ.get("DATABASE_URL", "")' in migration_env


def test_deployment_keeps_single_worker_for_the_in_process_otp_broker() -> None:
    entrypoint = (ROOT / "deploy" / "entrypoint.sh").read_text(encoding="utf-8")
    caddy = (ROOT / "deploy" / "Caddyfile").read_text(encoding="utf-8")
    plan = (ROOT / "docs" / "superpowers" / "plans" / "2026-08-23-air724-websocket-otp.md").read_text(encoding="utf-8")

    assert "--workers 1" in entrypoint
    assert "reverse_proxy app:{$APP_PORT}" in caddy
    assert "single-process" in plan
    assert "shared Redis/PostgreSQL notification broker" in plan


def test_air724_download_package_is_in_the_server_assets() -> None:
    downloads = ROOT / "web" / "public" / "assets" / "downloads"

    assert (downloads / "air724-otp-websocket.lua").is_file()
    assert (downloads / "air724-otp-websocket" / "main.lua").is_file()
    assert (downloads / "air724-mqtt-ingest.lua").is_file()
    assert (downloads / "air724-otp-websocket" / "config.example.lua").is_file()
    assert (downloads / "air724-otp-websocket" / "README.md").is_file()


def test_generic_script_api_reference_client_is_in_the_server_package_source() -> None:
    script_client = ROOT / "clients" / "script_api"

    assert (script_client / "otp_client.py").is_file()
    assert (script_client / "README.md").is_file()
    assert (ROOT / "backend" / "tests" / "test_script_api_network.py").is_file()


def test_alembic_has_no_implicit_local_database_fallback() -> None:
    alembic_ini = (ROOT / "backend" / "alembic.ini").read_text(encoding="utf-8")
    migration_env = (ROOT / "backend" / "migrations" / "env.py").read_text(encoding="utf-8")

    assert "relay-dev.db" not in alembic_ini
    assert "__DATABASE_URL_REQUIRED__" in alembic_ini
    assert "DATABASE_URL must be set" in migration_env


def test_repository_ignores_runtime_databases() -> None:
    ignore = (ROOT / ".gitignore").read_text(encoding="utf-8")

    assert "*.db" in ignore
    assert "*.db.bak-*" in ignore
    assert "*-wal" in ignore
    assert "*-shm" in ignore


def test_database_artifacts_are_ignored_and_storage_boundaries_are_documented() -> None:
    gitignore = (ROOT / ".gitignore").read_text(encoding="utf-8")
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    deploy_readme = (ROOT / "deploy" / "README.md").read_text(encoding="utf-8")

    for pattern in ("*.db", "*.db-wal", "*.db-shm", "*.sqlite", "*.sqlite3"):
        assert pattern in gitignore
    assert "`database_fingerprint`" in deploy_readme
    assert "`postgres_data`" in deploy_readme
    assert "`/data/adb/sms-relay`" in readme
    assert "`sms-relay-queue.db`" in readme


def test_server_package_excludes_local_runtime_and_secret_files() -> None:
    package_script = (ROOT / "deploy" / "package.ps1").read_text(encoding="utf-8")

    assert "web/public" in package_script
    assert "node_modules" in package_script
    assert "backend/.venv" in package_script
    assert "backend/.mypy_cache" in package_script
    assert "backend/.pytest_cache" in package_script
    assert "backend/.ruff_cache" in package_script
    assert "__pycache__" in package_script
    assert "sqlite3" in package_script
    assert ".pyc" in package_script
    assert "deploy/.env" in package_script
    assert "deploy/dist" in package_script
    assert ".dockerignore" in package_script
    assert "web/public/assets/downloads/air724-otp-websocket.lua" in package_script
    assert "web/public/assets/downloads/air724-otp-websocket/main.lua" in package_script
    assert "web/public/assets/downloads/air724-otp-websocket/config.example.lua" in package_script
    assert "web/public/assets/downloads/air724-otp-websocket/README.md" in package_script
    assert "web/public/assets/downloads/air724-mqtt-ingest.lua" in package_script
    assert "clients/air724/mqtt_ingest.lua" in package_script
    assert "backend/app/mqtt_bridge.py" in package_script
    assert "clients/script_api/otp_client.py" in package_script
    assert "clients/script_api/README.md" in package_script
    assert "web/public/assets/releases/release-catalog.json" in package_script
    assert "release.download_url" in package_script
    assert 'platform -ne "deploy"' in package_script
    assert "Select-Object -First 2" in package_script
    assert "web/public/downloads" in package_script
    assert "sms-relay-root-module-*.zip" in package_script
    assert "manager-android" in package_script
    assert "*.p12" in package_script
    assert "*signing.properties" in package_script


def test_manager_release_scripts_require_external_signing_and_publish_history() -> None:
    build_script = (ROOT / "manager-android" / "build-release.ps1").read_text(encoding="utf-8")
    publish_script = (ROOT / "manager-android" / "publish-update.ps1").read_text(encoding="utf-8")

    for variable in (
        "RELAY_MANAGER_SIGNING_STORE_FILE",
        "RELAY_MANAGER_SIGNING_STORE_PASSWORD",
        "RELAY_MANAGER_SIGNING_KEY_ALIAS",
        "RELAY_MANAGER_SIGNING_KEY_PASSWORD",
    ):
        assert variable in build_script
    assert "io.smsrelay.manager" in publish_script
    assert "platform = 'manager'" in publish_script
    assert "Relay-Hub-Manager-$versionName.apk" in publish_script
    assert "Signer SHA-256" in publish_script


def _kts_value(source: str, key: str) -> str:
    for line in source.splitlines():
        stripped = line.strip()
        if stripped.startswith(f"{key} ="):
            return stripped.split("=", 1)[1].strip().strip('"')
    raise AssertionError(f"{key} is missing from build.gradle.kts")


def test_published_manager_release_matches_catalog_and_apk() -> None:
    gradle = (ROOT / "manager-android" / "app" / "build.gradle.kts").read_text(encoding="utf-8")
    expected_code = int(_kts_value(gradle, "versionCode"))
    expected_name = _kts_value(gradle, "versionName")

    catalog_path = ROOT / "web" / "public" / "assets" / "releases" / "release-catalog.json"
    catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
    manager_releases = [release for release in catalog["releases"] if release["platform"] == "manager"]

    assert manager_releases
    release = max(manager_releases, key=lambda item: item["version_code"])
    assert release["version_code"] == expected_code
    assert release["version_name"] == expected_name
    assert release["download_url"].startswith("/assets/releases/manager/")
    assert len(release["signer_sha256"]) == 64
    apk = ROOT / "web" / "public" / release["download_url"].removeprefix("/")
    assert apk.is_file()
    assert apk.stat().st_size == release["size_bytes"]
    assert hashlib.sha256(apk.read_bytes()).hexdigest() == release["sha256"]


def _prop_value(source: str, key: str) -> str:
    for line in source.splitlines():
        stripped = line.strip()
        if stripped.startswith(f"{key}="):
            return stripped.split("=", 1)[1].strip()
    raise AssertionError(f"{key} is missing from module.prop")


def test_root_module_publish_script_and_release_history_are_consistent() -> None:
    publish_script = (ROOT / "clients" / "root-module" / "publish-update.ps1").read_text(encoding="utf-8")
    assert "platform = 'root'" in publish_script
    assert "signer_sha256 = $null" in publish_script
    assert "module.prop" in publish_script

    module_prop = (ROOT / "clients" / "root-module" / "module.prop").read_text(encoding="utf-8")
    expected_code = int(_prop_value(module_prop, "versionCode"))
    expected_name = _prop_value(module_prop, "version")

    catalog_path = ROOT / "web" / "public" / "assets" / "releases" / "release-catalog.json"
    catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
    root_releases = [release for release in catalog["releases"] if release["platform"] == "root"]
    assert root_releases
    release = max(root_releases, key=lambda item: item["version_code"])
    assert release["version_code"] == expected_code
    assert release["version_name"] == expected_name
    assert release["signer_sha256"] is None
    archive = ROOT / "web" / "public" / release["download_url"].removeprefix("/")
    assert archive.is_file()
    assert archive.stat().st_size == release["size_bytes"]
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == release["sha256"]


def test_container_update_package_preserves_release_store_and_matches_catalog() -> None:
    package_update = (ROOT / "deploy" / "package-update.ps1").read_text(encoding="utf-8")
    package_script = (ROOT / "deploy" / "package.ps1").read_text(encoding="utf-8")
    publish_update = (ROOT / "deploy" / "publish-update.ps1").read_text(encoding="utf-8")
    apply_update = (ROOT / "deploy" / "apply-update.sh").read_text(encoding="utf-8")

    assert "ExcludeReleaseStore" not in package_update
    assert "ExcludeReleaseStore" not in package_script
    assert "web/public/assets/releases" in package_script
    assert "platform = 'deploy'" in publish_update
    assert "signer_sha256 = $null" in publish_update
    assert "relay-backup-" in apply_update
    assert '"platform"[[:space:]]*:[[:space:]]*"deploy"' in apply_update
    assert "web/public/assets/releases/deploy" in apply_update
    assert "web/public/assets/releases" in apply_update
    assert "deploy/.env" in apply_update
    assert "docker compose" in apply_update
    assert "compose build --no-cache app" in apply_update
    assert 'cp "$SOURCE_ROOT/deploy/compose.yml" "$TARGET/deploy/compose.yml"' in apply_update
    assert 'update package is missing the filtered release catalog' in apply_update
    assert 'find "$BACKUP_DIR/release-store" -type f' not in apply_update
    assert 'if [ ! -e "$target_release_file" ]; then' not in apply_update
    assert 'cp "$SOURCE_ROOT/web/public/assets/releases/release-catalog.json"' not in apply_update
    assert 'cp -a "$SOURCE_ROOT/backend" "$SOURCE_ROOT/clients" "$SOURCE_ROOT/deploy" "$SOURCE_ROOT/web" "$TARGET/"' in apply_update

    catalog_path = ROOT / "web" / "public" / "assets" / "releases" / "release-catalog.json"
    catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
    deploy_releases = [release for release in catalog["releases"] if release["platform"] == "deploy"]
    assert deploy_releases
    release = max(deploy_releases, key=lambda item: item["version_code"])
    assert release["version_code"] >= 20260901
    assert release["version_name"]
    assert release["signer_sha256"] is None
    archive = ROOT / "web" / "public" / release["download_url"].removeprefix("/")
    assert archive.is_file()
    assert archive.stat().st_size == release["size_bytes"]
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == release["sha256"]


def test_every_release_catalog_artifact_matches_declared_size_and_hash() -> None:
    catalog_path = ROOT / "web" / "public" / "assets" / "releases" / "release-catalog.json"
    catalog = json.loads(catalog_path.read_text(encoding="utf-8"))

    assert catalog["releases"]
    for release in catalog["releases"]:
        artifact = ROOT / "web" / "public" / release["download_url"].removeprefix("/")
        assert artifact.is_file(), release["download_url"]
        assert artifact.stat().st_size == release["size_bytes"], release["download_url"]
        assert hashlib.sha256(artifact.read_bytes()).hexdigest() == release["sha256"], release["download_url"]
